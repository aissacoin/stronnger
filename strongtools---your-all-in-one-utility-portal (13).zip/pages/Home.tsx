import React, { useState, useMemo } from 'react';
import { TOOLS } from '../constants';
import { ToolModal } from '../components/ToolModal';
import { ToolCategory } from '../types';
import { Search, ChevronRight, Zap, Briefcase } from 'lucide-react';
import * as LucideIcons from 'lucide-react';
import { useLanguage } from '../components/LanguageContext';

// --- Tool Modules Re-import (Optimized List) ---
import { WordCounter } from '../components/tools/WordCounter';
import { WordCounterPerPage } from '../components/tools/WordCounterPerPage';
import { OnlineNotepad } from '../components/tools/OnlineNotepad';
import { AIHumanizer } from '../components/tools/AIHumanizer';
import { GrammarFixer } from '../components/tools/GrammarFixer';
import { CaseConverter } from '../components/tools/CaseConverter';
import { TextCleaner } from '../components/tools/TextCleaner';
import { NumberExtractor } from '../components/tools/NumberExtractor';
import { LanguageExtractor } from '../components/tools/LanguageExtractor';
import { EmailExtractor } from '../components/tools/EmailExtractor';
import { DomainExtractor } from '../components/tools/DomainExtractor';
import { KeywordDensityChecker } from '../components/tools/KeywordDensityChecker';
import { CVMaker } from '../components/tools/CVMaker';
import { LessonPlanGen } from '../components/tools/LessonPlanGen';
import { ExamPlanner } from '../components/tools/ExamPlanner';
import { FakeAddressGenerator } from '../components/tools/FakeAddressGenerator';
import { DimensionForge } from '../components/tools/DimensionForge';
import { AIBackgroundRemover } from '../components/tools/AIBackgroundRemover';
import { AIPhotoEnhancer } from '../components/tools/AIPhotoEnhancer';
import { BackgroundShifter } from '../components/tools/BackgroundShifter';
import { BackgroundArchitect } from '../components/tools/BackgroundArchitect';
import { HairColorArchitect } from '../components/tools/HairColorArchitect';
import { GroomingSimulator } from '../components/tools/GroomingSimulator';
import { ImageStoryteller } from '../components/tools/ImageStoryteller';
import { CollageMaker } from '../components/tools/CollageMaker';
import { SocialResizer } from '../components/tools/SocialResizer';
import { ColorPickerFromImage } from '../components/tools/ColorPickerFromImage';
import { ColorGenerator } from '../components/tools/ColorGenerator';
import { FaviconGenerator } from '../components/tools/FaviconGenerator';
import { QRGenerator } from '../components/tools/QRGenerator';
import { WebPToPNG } from '../components/tools/WebPToPNG';
import { YouTubeScriptGen } from '../components/tools/YouTubeScriptGen';
import { YouTubeTagExtractor } from '../components/tools/YouTubeTagExtractor';
import { AIYouTubeHookGen } from '../components/tools/AIYouTubeHookGen';
import { AIThumbnailForge } from '../components/tools/AIThumbnailForge';
import { InstagramCaptionGen } from '../components/tools/InstagramCaptionGen';
import { InstaGridPlanner } from '../components/tools/InstaGridPlanner';
import { TweetToImageConverter } from '../components/tools/TweetToImageConverter';
import { TweetThreadGen } from '../components/tools/TweetThreadGen';
import { TikTokVoiceoverGen } from '../components/tools/TikTokVoiceoverGen';
import { AITikTokTrendOracle } from '../components/tools/AITikTokTrendOracle';
import { LinkedInPostArchitect } from '../components/tools/LinkedInPostArchitect';
import { AILinkedInBioArchitect } from '../components/tools/AILinkedInBioArchitect';
import { BioGenerator } from '../components/tools/BioGenerator';
import { HashtagGenerator } from '../components/tools/HashtagGenerator';
import { EmailSignatureGenerator } from '../components/tools/EmailSignatureGenerator';
import { JSONConverter } from '../components/tools/JSONConverter';
import { JSONToTypeScript } from '../components/tools/JSONToTypeScript';
import { JSONYamlTransmuter } from '../components/tools/JSONYamlTransmuter';
import { SQLFormatter } from '../components/tools/SQLFormatter';
import { SQLToLaravel } from '../components/tools/SQLToLaravel';
import { HTMLToTailwind } from '../components/tools/HTMLToTailwind';
import { DockerNodeGen } from '../components/tools/DockerNodeGen';
import { RegexTester } from '../components/tools/RegexTester';
import { JWTDebugger } from '../components/tools/JWTDebugger';
import { CryptoPLCalc } from '../components/tools/CryptoPLCalc';
import { PersonalInflationCalculator } from '../components/tools/PersonalInflationCalculator';
import { CapRateCalculator } from '../components/tools/CapRateCalculator';
import { GPACalculator } from '../components/tools/GPACalculator';
import { UnitConverter } from '../components/tools/UnitConverter';
import { BMICalculator } from '../components/tools/BMICalculator';
import { AgeOracle } from '../components/tools/AgeOracle';

export const renderToolLogic = (id: string) => {
  switch (id) {
    case 'word-counter': return <WordCounter />;
    case 'word-counter-per-page': return <WordCounterPerPage />;
    case 'notepad': return <OnlineNotepad />;
    case 'ai-humanizer': return <AIHumanizer />;
    case 'grammar-fixer': return <GrammarFixer />;
    case 'case-converter': return <CaseConverter />;
    case 'text-cleaner': return <TextCleaner />;
    case 'number-extractor': return <NumberExtractor />;
    case 'lang-extractor': return <LanguageExtractor />;
    case 'email-extractor': return <EmailExtractor />;
    case 'domain-extractor': return <DomainExtractor />;
    case 'keyword-density': return <KeywordDensityChecker />;
    case 'cv-maker': return <CVMaker />;
    case 'lesson-plan': return <LessonPlanGen />;
    case 'exam-planner': return <ExamPlanner />;
    case 'fake-address': return <FakeAddressGenerator />;
    case 'dimension-forge': return <DimensionForge />;
    case 'bg-remover': return <AIBackgroundRemover />;
    case 'photo-enhancer': return <AIPhotoEnhancer />;
    case 'bg-shifter': return <BackgroundShifter />;
    case 'bg-architect': return <BackgroundArchitect />;
    case 'hair-architect': return <HairColorArchitect />;
    case 'grooming-sim': return <GroomingSimulator />;
    case 'image-storyteller': return <ImageStoryteller />;
    case 'collage-maker': return <CollageMaker />;
    case 'social-resizer': return <SocialResizer />;
    case 'color-picker': return <ColorPickerFromImage />;
    case 'color-gen': return <ColorGenerator />;
    case 'favicon-gen': return <FaviconGenerator />;
    case 'qr-gen': return <QRGenerator />;
    case 'webp-to-png': return <WebPToPNG />;
    case 'yt-script-gen': return <YouTubeScriptGen />;
    case 'yt-tag-extractor': return <YouTubeTagExtractor />;
    case 'yt-hook-gen': return <AIYouTubeHookGen />;
    case 'yt-thumbnail-forge': return <AIThumbnailForge />;
    case 'insta-caption': return <InstagramCaptionGen />;
    case 'insta-grid': return <InstaGridPlanner />;
    case 'tweet-to-image': return <TweetToImageConverter />;
    case 'tweet-thread': return <TweetThreadGen />;
    case 'tiktok-voiceover': return <TikTokVoiceoverGen />;
    case 'tiktok-trend': return <AITikTokTrendOracle />;
    case 'linkedin-post': return <LinkedInPostArchitect />;
    case 'linkedin-bio': return <AILinkedInBioArchitect />;
    case 'bio-gen': return <BioGenerator />;
    case 'hashtag-gen': return <HashtagGenerator />;
    case 'email-sig': return <EmailSignatureGenerator />;
    case 'json-converter': return <JSONConverter />;
    case 'json-to-ts': return <JSONToTypeScript />;
    case 'json-yaml': return <JSONYamlTransmuter />;
    case 'sql-formatter': return <SQLFormatter />;
    case 'sql-to-laravel': return <SQLToLaravel />;
    case 'html-to-tailwind': return <HTMLToTailwind />;
    case 'docker-gen': return <DockerNodeGen />;
    case 'regex-tester': return <RegexTester />;
    case 'jwt-debugger': return <JWTDebugger />;
    case 'crypto-calc': return <CryptoPLCalc />;
    case 'inflation-calc': return <PersonalInflationCalculator />;
    case 'cap-rate': return <CapRateCalculator />;
    case 'gpa-calc': return <GPACalculator />;
    case 'unit-calc': return <UnitConverter />;
    case 'bmi-calc': return <BMICalculator />;
    case 'age-oracle': return <AgeOracle />;
    default: return <div className="text-center py-20 text-gray-500 italic uppercase tracking-widest text-[10px]">Loading Module...</div>;
  }
};

export const Home: React.FC = () => {
  const [selectedToolId, setSelectedToolId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const { t, language } = useLanguage();
  
  const categories = useMemo(() => {
    return ['All', ...Object.values(ToolCategory).filter(cat => cat !== ToolCategory.TIME)];
  }, []);
  
  const filteredTools = useMemo(() => {
    return TOOLS.filter(tool => {
      // الحصول على الترجمة الحقيقية من القاموس بناءً على ID الأداة
      const toolInfo = t.tools?.[tool.id] || { name: tool.id, desc: '' };
      const nameMatch = toolInfo.name.toLowerCase().includes(searchTerm.toLowerCase());
      const descMatch = toolInfo.desc.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesSearch = nameMatch || descMatch;
      const matchesCategory = activeCategory === 'All' || tool.category === activeCategory;
      return matchesSearch && matchesCategory;
    });
  }, [searchTerm, activeCategory, t]);

  const selectedTool = TOOLS.find(t => t.id === selectedToolId);

  return (
    <div key={language} className={`min-h-screen bg-[#050505] text-white ${t.dir === 'rtl' ? 'text-right' : 'text-left'}`} dir={t.dir}>
      {/* Hero Section */}
      <section className="pt-32 pb-16 px-6 text-center border-b border-white/5 relative overflow-hidden">
        <div className="max-w-4xl mx-auto space-y-8 relative z-10">
          <div className="inline-flex items-center gap-3 px-5 py-2 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/20 text-[#D4AF37] text-[10px] font-black uppercase tracking-[0.4em] mb-4">
             <Briefcase size={14} /> {t.heroTag}
          </div>
          <h1 className="text-4xl md:text-7xl font-black tracking-tighter uppercase italic leading-none">
            {t.heroTitle}
          </h1>
          <p className="text-gray-400 text-lg md:text-xl font-medium max-w-2xl mx-auto italic leading-relaxed">
            {t.heroSub}
          </p>
          
          <div className="relative max-w-2xl mx-auto mt-12">
            <Search className={`absolute ${t.dir === 'rtl' ? 'right-6' : 'left-6'} top-1/2 -translate-y-1/2 text-gray-700`} size={24} />
            <input 
              type="text" 
              placeholder={t.searchPlaceholder}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className={`w-full bg-[#0d0d0d] border border-white/10 rounded-3xl py-6 ${t.dir === 'rtl' ? 'pr-16 pl-6' : 'pl-16 pr-6'} text-white text-lg focus:border-[#D4AF37] outline-none transition-all shadow-2xl`}
            />
          </div>
        </div>
      </section>

      {/* Category Bar */}
      <section className="sticky top-16 z-40 bg-[#050505]/95 backdrop-blur-2xl border-b border-white/5 overflow-x-auto no-scrollbar">
        <div className="max-w-7xl mx-auto px-6 py-5 flex gap-5">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-8 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest whitespace-nowrap border transition-all ${
                activeCategory === cat ? 'bg-[#D4AF37] text-black border-[#D4AF37]' : 'bg-white/5 text-gray-500 border-white/5 hover:text-white'
              }`}
            >
              {t.categories[cat] || cat}
            </button>
          ))}
        </div>
      </section>

      {/* Tools Grid */}
      <main className="max-w-7xl mx-auto px-6 py-20">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {filteredTools.map((tool) => {
            // سحب النص المترجم الفعلي
            const info = t.tools?.[tool.id] || { name: tool.id, desc: 'Translation Missing' };
            
            return (
              <button 
                key={tool.id}
                onClick={() => setSelectedToolId(tool.id)}
                className={`group bg-[#0d0d0d] border border-white/5 p-10 rounded-[2.5rem] ${t.dir === 'rtl' ? 'text-right' : 'text-left'} hover:border-[#D4AF37]/50 transition-all hover:-translate-y-2 relative overflow-hidden shadow-xl`}
              >
                <div className="w-14 h-14 rounded-2xl bg-[#D4AF37]/10 flex items-center justify-center text-[#D4AF37] mb-8 group-hover:scale-110 transition-transform border border-[#D4AF37]/20">
                  {React.createElement((LucideIcons as any)[tool.icon] || Zap, { size: 28 })}
                </div>
                <h3 className="text-2xl font-black uppercase italic mb-3 tracking-tighter leading-tight">{info.name}</h3>
                <p className="text-xs text-gray-500 line-clamp-3 leading-relaxed italic">{info.desc}</p>
                <div className={`mt-8 flex items-center gap-2 text-[9px] font-black uppercase text-[#D4AF37] tracking-widest opacity-0 group-hover:opacity-100 transition-all`}>
                  {t.common.deploy} <ChevronRight size={12} className={t.dir === 'rtl' ? 'rotate-180' : ''} />
                </div>
              </button>
            );
          })}
        </div>
      </main>

      {selectedTool && (
        <ToolModal 
          isOpen={!!selectedToolId} 
          onClose={() => setSelectedToolId(null)} 
          title={t.tools?.[selectedTool.id]?.name || selectedTool.name} 
          toolId={selectedTool.id}
        >
          {renderToolLogic(selectedTool.id)}
        </ToolModal>
      )}
    </div>
  );
};