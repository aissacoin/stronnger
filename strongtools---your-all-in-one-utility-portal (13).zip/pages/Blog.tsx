
import React, { useEffect, useState } from 'react';
import { BookOpen, Clock, ArrowRight, Search, Loader2, History } from 'lucide-react';
import { getDailyChronicles } from '../services/geminiService';

const BlogPostCard: React.FC<{ post: any }> = ({ post }) => {
  // التأكد من أن الرابط يتبع نمط الهاش المتوافق مع App.tsx
  const articleLink = `#/blog/${post.id}`;

  return (
    <article className="bg-[#0d0d0d] rounded-[2.5rem] overflow-hidden group flex flex-col h-full border border-white/5 hover:border-[#D4AF37]/30 transition-all shadow-xl">
      <div className="p-10 flex flex-col flex-grow space-y-6">
        <div className="flex items-center gap-4 text-[#D4AF37]/40 text-[10px] font-black uppercase tracking-widest">
          <div className="flex items-center gap-1"><Clock size={12}/> {post.date}</div>
          <span className="bg-[#D4AF37]/10 px-3 py-1 rounded-full text-[#D4AF37]">{post.category}</span>
        </div>
        <h2 className="text-2xl font-black leading-tight group-hover:text-[#D4AF37] transition-colors italic uppercase">
          {post.title}
        </h2>
        <p className="text-gray-500 text-sm italic flex-grow leading-relaxed">
          {post.excerpt}
        </p>
        <a 
          href={articleLink} 
          className="inline-flex items-center gap-2 text-[#D4AF37] font-black text-xs uppercase tracking-widest hover:text-white transition-all group/link"
        >
          Read Full Manuscript <ArrowRight size={16} className="group-hover/link:translate-x-2 transition-transform" />
        </a>
      </div>
    </article>
  );
};

export const Blog: React.FC = () => {
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    getDailyChronicles().then(data => {
      setPosts(data);
      setLoading(false);
    });
  }, []);

  const filteredPosts = posts.filter(p => 
    p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-[#050505] min-h-screen text-white py-32 px-4">
      <div className="max-w-7xl mx-auto space-y-16">
        <div className="text-center space-y-6">
          <div className="inline-flex items-center gap-3 px-6 py-2 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/30 text-[#D4AF37] text-[10px] font-black uppercase tracking-[0.5em] mb-4">
            <History size={16} /> Knowledge Repository
          </div>
          <h1 className="text-6xl md:text-8xl font-black uppercase tracking-tighter italic">The <span className="text-[#D4AF37]">Articles</span></h1>
          <p className="text-xl text-gray-500 italic max-w-2xl mx-auto">"Deep technical insights and logical foundations for every sovereign instrument in our vault."</p>
          
          <div className="relative max-w-xl mx-auto mt-12">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
            <input 
              type="text" 
              placeholder="Filter manuscripts..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#0d0d0d] border border-white/10 rounded-2xl py-4 pl-14 pr-6 text-white focus:border-[#D4AF37] outline-none transition-all"
            />
          </div>
        </div>

        {loading ? (
          <div className="py-40 text-center space-y-6">
            <Loader2 className="animate-spin mx-auto text-[#D4AF37]" size={64} />
            <p className="text-[10px] font-black uppercase tracking-widest text-[#D4AF37]">Synchronizing with Knowledge Nodes...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {filteredPosts.map((post) => (
              <BlogPostCard key={post.id} post={post} />
            ))}
          </div>
        )}

        <div className="w-full h-32 bg-white/5 rounded-[2.5rem] flex items-center justify-center border border-white/5 text-[8px] text-gray-800 uppercase tracking-widest mt-20">
          Google AdSense In-Feed Ad Node
        </div>
      </div>
    </div>
  );
};
