
export type Language = 'en' | 'ar' | 'fr' | 'es' | 'it' | 'ru' | 'pt' | 'tr';

const COMMON_AR = { 
  copy: 'نسخ', copied: 'تم النسخ', clear: 'مسح', calculate: 'حساب', upload: 'رفع ملف', 
  deploy: 'افتح الأداة', search: 'ابحث عن أداة...', results: 'نتائج', loading: 'جاري التحميل...',
  howToUse: 'الدليل التقني والأسئلة الشائعة', privacyProtocol: 'بروتوكول خصوصية البيانات المحلي',
  about: 'عن الأداة', usage: 'كيفية الاستعمال', benefits: 'الفوائد', faq: 'الأسئلة الشائعة'
};

const FOOTER_AR = {
  archives: 'الأرشيف', browse: 'تصفح الأدوات', chronicles: 'المقالات التقنية', index: 'فهرس الأدوات',
  directives: 'التوجيهات', about: 'حول المنصة', missive: 'اتصل بنا', status: 'حالة النظام',
  sovereignty: 'السيادة', privacy: 'سياسة الخصوصية', terms: 'شروط الخدمة', locality: 'محلي بالكامل',
  rigor: 'معيار الدقة العالمية MMXXV'
};

const FOOTER_EN = {
  archives: 'Archives', browse: 'Browse', chronicles: 'Articles', index: 'Index',
  directives: 'Directives', about: 'About', missive: 'Contact', status: 'Status',
  sovereignty: 'Sovereignty', privacy: 'Privacy', terms: 'Terms', locality: 'Local',
  rigor: 'Standard MMXXV'
};

export const TRANSLATIONS: Record<Language, any> = {
  en: {
    dir: 'ltr', brand: 'StrongTools', navHome: 'Home', navArticles: 'Articles', navAbout: 'About', navContact: 'Contact',
    heroTag: 'Sovereign Utility Archive', heroTitle: 'Smart Tools for Better Work', heroSub: 'Secure, fast, and private tools for developers and creators.',
    searchPlaceholder: 'Search for a tool...', footerSub: 'A curated sanctuary for the discerning professional.',
    registryLabel: 'Sovereign Registry MMXXV', 
    common: { 
      copy: 'Copy', copied: 'Copied', clear: 'Clear', calculate: 'Calculate', upload: 'Upload', 
      deploy: 'Open Tool', search: 'Search for tool...', results: 'Results', loading: 'Loading...',
      howToUse: 'Technical Guide & FAQ', privacyProtocol: 'Local Data Privacy Protocol',
      about: 'About Tool', usage: 'Usage Guide', benefits: 'Benefits', faq: 'FAQ'
    },
    footer: FOOTER_EN,
    categories: { All: 'All', Productivity: 'Office', Finance: 'Money', Knowledge: 'Learning', Conversion: 'Design', Generators: 'Social' },
    tools: {
      'word-counter': { 
        name: 'Word Counter', desc: 'Real-time analytics.',
        doc: {
          about: 'The Word Counter is a precision instrument designed for deep lexical analysis. It processes text in real-time to provide metrics vital for publishers and SEO experts.',
          usage: '1. Ingest your text into the terminal. 2. Observe live metrics. 3. Use results for manuscript calibration.',
          benefits: 'Ensures compliance with platform limits and optimizes reading flow through temporal estimation.',
          faq: [
            { q: 'Is my text sent to a server?', a: 'No. All lexical processing occurs locally in your browser memory.' },
            { q: 'How is reading time calculated?', a: 'Based on a standard high-fidelity constant of 200 words per minute.' }
          ]
        },
        internal: { placeholder: 'Start typing here...', words: 'Words', chars: 'Chars', sentences: 'Sentences', time: 'Read Time' }
      },
      'bmi-calc': {
        name: 'BMI Analyzer', desc: 'Health equilibrium scale.',
        doc: {
          about: 'A biometric node that calculates Body Mass Index to evaluate physical health metrics according to global clinical standards.',
          usage: 'Enter height (cm) and weight (kg). The algorithm will instantly map your coordinate on the health spectrum.',
          benefits: 'Provides instant health baseline without requiring external medical hardware.',
          faq: [
            { q: 'Is this a medical diagnosis?', a: 'No. It is a mathematical indicator for informational purposes.' }
          ]
        },
        internal: { weight: 'Weight (kg)', height: 'Height (cm)', status: 'Health Status' },
        status: { u: 'Underweight', n: 'Normal', o: 'Overweight', ob: 'Obese' }
      }
      // ... (يتم تكرار هذا النمط لجميع الأدوات الـ 60 بالإنجليزية)
    }
  },
  ar: {
    dir: 'rtl',
    brand: 'سترونج تولز',
    navHome: 'الرئيسية',
    navArticles: 'المقالات',
    navAbout: 'حول',
    navContact: 'اتصل بنا',
    heroTag: 'الأرشيف السيادي للأدوات',
    heroTitle: 'أدوات ذكية لعمل أفضل',
    heroSub: 'أدوات آمنة وسريعة وخاصة للمطورين والمبدعين.',
    searchPlaceholder: 'ابحث عن أداة من بين 60 أداة...',
    footerSub: 'ملاذ منتقى للمحترفين، حيث تلتقي الرياضيات بالتميز الرقمي والخصوصية المطلقة.',
    registryLabel: 'السجل السيادي 2025',
    common: COMMON_AR,
    footer: FOOTER_AR,
    categories: { All: 'الكل', Productivity: 'مكتب', Finance: 'مال', Knowledge: 'تعليم', Conversion: 'تصميم', Generators: 'سوشيال' },
    tools: {
      'word-counter': { 
        name: 'عداد الكلمات', desc: 'تحليل فوري للكلمات والحروف.', 
        doc: {
          about: 'عداد الكلمات هو أداة دقيقة مصممة للتحليل اللغوي العميق. يقوم بمعالجة النصوص في الوقت الفعلي لتوفير مقاييس حيوية للناشرين وخبراء السيو.',
          usage: '1. أدخل نصك في المحطة. 2. راقب المقاييس المباشرة. 3. استخدم النتائج لمعايرة المخطوطة.',
          benefits: 'يضمن الامتثال لقيود المنصات ويحسن تدفق القراءة من خلال تقدير الوقت الزمني.',
          faq: [
            { q: 'هل يتم إرسال نصي إلى خادم؟', a: 'لا. تتم جميع عمليات المعالجة اللغوية محليًا في ذاكرة متصفحك.' },
            { q: 'كيف يتم حساب وقت القراءة؟', a: 'بناءً على ثابت عالمي عالي الدقة يبلغ 200 كلمة في الدقيقة.' }
          ]
        },
        internal: { placeholder: 'ابدأ الكتابة هنا...', words: 'كلمات', chars: 'حروف', sentences: 'جمل', time: 'وقت القراءة' }
      },
      'bmi-calc': { 
        name: 'محلل كتلة الجسم', desc: 'مقياس التوازن الحيوي والصحي للوزن.', 
        doc: {
          about: 'عقدة بيومترية تحسب مؤشر كتلة الجسم لتقييم مقاييس الصحة البدنية وفقاً للمعايير السريرية العالمية.',
          usage: 'أدخل الطول (سم) والوزن (كجم). سيقوم الخوارزمي فوراً بتحديد إحداثياتك على طيف الصحة.',
          benefits: 'يوفر خط أساس صحي فوري دون الحاجة إلى أجهزة طبية خارجية.',
          faq: [
            { q: 'هل هذا تشخيص طبي؟', a: 'لا. هو مؤشر رياضي للأغراض المعلوماتية فقط.' }
          ]
        },
        internal: { weight: 'الوزن (كجم)', height: 'الطول (سم)', status: 'الحالة الصحية' },
        status: { u: 'نقص وزن', n: 'وزن مثالي', o: 'وزن زائد', ob: 'سمنة مفرطة' }
      },
      'qr-gen': {
        name: 'مهندس الـ QR', desc: 'توليد أكواد الاستجابة السريعة.',
        doc: {
          about: 'أداة لتوليد أكواد QR عالية الدقة مشفرة للاستخدام في الهوية الرقمية والروابط التسويقية.',
          usage: '1. الصق الرابط المطلوب. 2. سيظهر الكود فوراً. 3. قم بتحميله بصيغة PNG عالية الجودة.',
          benefits: 'سرعة مشاركة البيانات وتوافق كامل مع كافة ماسحات الأكواد العالمية.',
          faq: [
            { q: 'هل تنتهي صلاحية الكود؟', a: 'لا، الأكواد المولدة دائمة ولا تعتمد على أي خوادم وسيطة.' }
          ]
        },
        internal: { label: 'الرابط المدخل', placeholder: 'ادخل الرابط هنا...', btnDownload: 'تحميل الكود PNG' }
      }
      // ... يتم إضافة التوثيق لكافة الـ 60 أداة بنفس النمط
    }
  },
  fr: { dir: 'ltr', brand: 'StrongTools', footerSub: 'Sanctuaire pour les professionnels.', registryLabel: 'Registre Souverain', common: { copy: 'Copier' }, footer: FOOTER_EN, categories: {}, tools: {} },
  es: { dir: 'ltr', brand: 'StrongTools', footerSub: 'Santuario para profesionales.', registryLabel: 'Registro Soberano', common: { copy: 'Copiar' }, footer: FOOTER_EN, categories: {}, tools: {} },
  it: { dir: 'ltr', brand: 'StrongTools', footerSub: 'Santuario per i professionisti.', registryLabel: 'Registro Sovrano', common: { copy: 'Copia' }, footer: FOOTER_EN, categories: {}, tools: {} },
  ru: { dir: 'ltr', brand: 'StrongTools', footerSub: 'Святилище для профессионалов.', registryLabel: 'Суверенный Реестр', common: { copy: 'Копировать' }, footer: FOOTER_EN, categories: {}, tools: {} },
  pt: { dir: 'ltr', brand: 'StrongTools', footerSub: 'Santuário para profissionais.', registryLabel: 'Registro Soberano', common: { copy: 'Copiar' }, footer: FOOTER_EN, categories: {}, tools: {} },
  tr: { dir: 'ltr', brand: 'StrongTools', footerSub: 'Profesyoneller için sığınak.', registryLabel: 'Egemen Kayıt', common: { copy: 'Kopyala' }, footer: FOOTER_EN, categories: {}, tools: {} }
};
