
import React, { useState } from 'react';
import { Menu, X, Search, ChevronRight, Home, LayoutGrid, Info, Mail, Twitter, Linkedin, Globe } from 'lucide-react';
import { useLanguage } from './LanguageContext';
import { Language } from '../translations';

const LANGUAGES_MAP = [
  { code: 'en', label: 'English' },
  { code: 'ar', label: 'العربية' },
  { code: 'fr', label: 'Français' },
  { code: 'es', label: 'Español' },
  { code: 'it', label: 'Italiano' },
  { code: 'ru', label: 'Русский' },
  { code: 'pt', label: 'Português' },
  { code: 'tr', label: 'Türkçe' }
];

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isLangOpen, setIsLangOpen] = useState(false);
  const { language, setLanguage, t } = useLanguage();

  const navigateTo = (path: string) => {
    setIsMenuOpen(false);
    window.location.hash = path;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className={`flex flex-col min-h-screen bg-[var(--bg-deep)] ${language === 'ar' ? 'font-arabic' : ''}`}>
      {/* Responsive Glass Header */}
      <header className="fixed top-0 left-0 right-0 z-50 glass-header px-4 md:px-6">
        <div className="max-w-[1440px] mx-auto flex justify-between items-center h-16 md:h-20">
          <button 
            onClick={() => navigateTo('#/')} 
            className="flex items-center gap-2 group outline-none"
          >
            <div className="w-8 h-8 md:w-10 md:h-10 bg-[#D4AF37] rounded-lg flex items-center justify-center text-black font-black text-lg md:text-xl shadow-[0_0_20px_rgba(212,175,55,0.3)] group-hover:scale-110 transition-transform">S</div>
            <span className="text-xl md:text-2xl font-black text-white tracking-tighter italic">{t.brand}</span>
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <button onClick={() => navigateTo('#/')} className="text-[10px] font-black uppercase tracking-widest text-zinc-400 hover:text-[#D4AF37] transition-colors flex items-center gap-2"><Home size={14}/> {t.navHome}</button>
            <button onClick={() => navigateTo('#/blog')} className="text-[10px] font-black uppercase tracking-widest text-zinc-400 hover:text-[#D4AF37] transition-colors flex items-center gap-2"><LayoutGrid size={14}/> {t.navArticles}</button>
            <button onClick={() => navigateTo('#/about')} className="text-[10px] font-black uppercase tracking-widest text-zinc-400 hover:text-[#D4AF37] transition-colors flex items-center gap-2"><Info size={14}/> {t.navAbout}</button>
            
            {/* Language Switcher */}
            <div className="relative">
              <button 
                onClick={() => setIsLangOpen(!isLangOpen)}
                className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-white/40 hover:text-[#D4AF37] transition-colors"
              >
                <Globe size={14} /> {LANGUAGES_MAP.find(l => l.code === language)?.label}
              </button>
              {isLangOpen && (
                <div className="absolute top-full mt-4 right-0 bg-[#0d0d0d] border border-white/10 rounded-2xl p-2 w-40 shadow-2xl animate-in fade-in slide-in-from-top-2">
                  {LANGUAGES_MAP.map(l => (
                    <button
                      key={l.code}
                      onClick={() => { setLanguage(l.code as Language); setIsLangOpen(false); }}
                      className={`w-full text-left px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-[#D4AF37] hover:text-black transition-all ${language === l.code ? 'text-[#D4AF37]' : 'text-gray-500'}`}
                    >
                      {l.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <button onClick={() => navigateTo('#/contact')} className="px-6 py-2.5 bg-[#D4AF37]/10 border border-[#D4AF37]/30 text-[#D4AF37] text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-[#D4AF37] hover:text-black transition-all">{t.navContact}</button>
          </nav>

          {/* Mobile Menu Toggle */}
          <div className="flex items-center gap-4 md:hidden">
             <button onClick={() => setIsLangOpen(!isLangOpen)} className="text-white/40 p-2"><Globe size={18}/></button>
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)} 
              className="w-10 h-10 bg-white/5 border border-white/10 rounded-xl flex items-center justify-center text-white"
            >
              {isMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
        {/* Mobile Language Overlay */}
        {isLangOpen && (
          <div className="md:hidden absolute top-full left-0 right-0 bg-black/95 p-4 border-b border-white/10 grid grid-cols-3 gap-2">
             {LANGUAGES_MAP.map(l => (
               <button key={l.code} onClick={() => { setLanguage(l.code as Language); setIsLangOpen(false); }} className="py-2 text-[8px] font-black uppercase tracking-widest border border-white/5 rounded-lg text-gray-500">{l.label}</button>
             ))}
          </div>
        )}
      </header>

      {/* Mobile Sidebar Menu */}
      <div className={`fixed inset-0 z-[60] bg-[#050505] transition-all duration-500 ease-in-out ${isMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}>
        <div className="flex flex-col h-full p-8 pt-24 space-y-8">
          <div className="flex justify-between items-center mb-8">
             <div className="text-[10px] font-black uppercase tracking-[0.5em] text-[#D4AF37]">{language === 'ar' ? 'القائمة الرئيسية' : 'Archival Menu'}</div>
             <button onClick={() => setIsMenuOpen(false)} className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center text-white"><X size={24}/></button>
          </div>
          
          <button onClick={() => navigateTo('#/')} className="w-full text-left py-6 text-4xl font-black italic border-b border-white/5 flex items-center justify-between group uppercase tracking-tighter">
             {t.navHome} <ChevronRight className={`${language === 'ar' ? 'rotate-180' : ''} text-[#D4AF37] group-hover:translate-x-2 transition-transform`} size={32}/>
          </button>
          <button onClick={() => navigateTo('#/blog')} className="w-full text-left py-6 text-4xl font-black italic border-b border-white/5 flex items-center justify-between group uppercase tracking-tighter">
             {t.navArticles} <ChevronRight className={`${language === 'ar' ? 'rotate-180' : ''} text-[#D4AF37] group-hover:translate-x-2 transition-transform`} size={32}/>
          </button>
          <button onClick={() => navigateTo('#/about')} className="w-full text-left py-6 text-4xl font-black italic border-b border-white/5 flex items-center justify-between group uppercase tracking-tighter">
             {t.navAbout} <ChevronRight className={`${language === 'ar' ? 'rotate-180' : ''} text-[#D4AF37] group-hover:translate-x-2 transition-transform`} size={32}/>
          </button>
          <button onClick={() => navigateTo('#/contact')} className="w-full text-left py-6 text-4xl font-black italic border-b border-white/5 flex items-center justify-between group uppercase tracking-tighter">
             {t.navContact} <ChevronRight className={`${language === 'ar' ? 'rotate-180' : ''} text-[#D4AF37] group-hover:translate-x-2 transition-transform`} size={32}/>
          </button>

          <div className="mt-auto py-10 space-y-4">
             <div className="flex gap-4">
                <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-white/40"><Mail size={20}/></div>
                <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-white/40"><Twitter size={20}/></div>
                <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-white/40"><Linkedin size={20}/></div>
             </div>
             <p className="text-[10px] font-black uppercase tracking-widest text-zinc-800">{t.registryLabel}</p>
          </div>
        </div>
      </div>

      <main className="flex-grow">{children}</main>

      {/* Simplified Footer */}
      <footer className="bg-[#050505] pt-24 pb-12 border-t border-white/5">
        <div className="max-w-[1440px] mx-auto px-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-16 mb-20">
            <div className="space-y-8">
              <div className="flex items-center gap-3">
                 <div className="w-8 h-8 bg-[#D4AF37] rounded flex items-center justify-center text-black font-black text-sm">S</div>
                 <span className="text-2xl font-black text-white italic tracking-tighter">{t.brand}</span>
              </div>
              <p className="text-zinc-500 text-sm leading-relaxed italic">
                {t.footerSub}
              </p>
            </div>
            
            <div className="space-y-8">
              <h5 className="text-[10px] font-black uppercase text-white tracking-[0.4em] italic underline decoration-[#D4AF37] underline-offset-8">{t.footer.archives}</h5>
              <nav className="flex flex-col gap-4 text-xs font-black uppercase tracking-widest text-zinc-600">
                <button onClick={() => navigateTo('#/')} className="hover:text-[#D4AF37] transition-all text-left">{t.footer.browse}</button>
                <button onClick={() => navigateTo('#/blog')} className="hover:text-[#D4AF37] transition-all text-left">{t.footer.chronicles}</button>
                <button onClick={() => navigateTo('#/tools')} className="hover:text-[#D4AF37] transition-all text-left">{t.footer.index}</button>
              </nav>
            </div>

            <div className="space-y-8">
              <h5 className="text-[10px] font-black uppercase text-white tracking-[0.4em] italic underline decoration-[#D4AF37] underline-offset-8">{t.footer.directives}</h5>
              <nav className="flex flex-col gap-4 text-xs font-black uppercase tracking-widest text-zinc-600">
                <button onClick={() => navigateTo('#/about')} className="hover:text-[#D4AF37] transition-all text-left">{t.footer.about}</button>
                <button onClick={() => navigateTo('#/contact')} className="hover:text-[#D4AF37] transition-all text-left">{t.footer.missive}</button>
                <button className="hover:text-[#D4AF37] transition-all text-left">{t.footer.status}</button>
              </nav>
            </div>

            <div className="space-y-8">
              <h5 className="text-[10px] font-black uppercase text-white tracking-[0.4em] italic underline decoration-[#D4AF37] underline-offset-8">{t.footer.sovereignty}</h5>
              <nav className="flex flex-col gap-4 text-xs font-black uppercase tracking-widest text-zinc-600">
                <button onClick={() => navigateTo('#/privacy')} className="hover:text-[#D4AF37] transition-all text-left">{t.footer.privacy}</button>
                <button onClick={() => navigateTo('#/terms')} className="hover:text-[#D4AF37] transition-all text-left">{t.footer.terms}</button>
                <button className="hover:text-[#D4AF37] transition-all text-left">{t.footer.locality}</button>
              </nav>
            </div>
          </div>

          <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex flex-col items-center md:items-start gap-2">
               <p className="text-zinc-700 text-[9px] font-black uppercase tracking-[0.5em]">
                 &copy; MMXXV {t.brand.toUpperCase()} • Global Archival Standard
               </p>
               <span className="text-[8px] text-zinc-800 font-bold uppercase tracking-widest">{t.footer.rigor}</span>
            </div>
            <div className="flex gap-4">
               {[1, 2, 3, 4].map((i) => (
                 <div key={i} className="w-1.5 h-1.5 rounded-full bg-zinc-900 border border-white/5"></div>
               ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
