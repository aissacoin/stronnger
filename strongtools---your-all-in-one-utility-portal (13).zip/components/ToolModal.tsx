
import React, { useEffect, useCallback } from 'react';
import { X, ShieldCheck, Info, Book, Target, HelpCircle, Zap } from 'lucide-react';
import { useLanguage } from './LanguageContext';

interface ToolModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  toolId?: string;
  children: React.ReactNode;
}

export const ToolModal: React.FC<ToolModalProps> = ({ isOpen, onClose, title, toolId, children }) => {
  const { t, language } = useLanguage();
  const isAr = language === 'ar';

  // إغلاق النافذة عند الضغط على زر Escape
  const handleKeyDown = useCallback((event: KeyboardEvent) => {
    if (event.key === 'Escape') {
      onClose();
    }
  }, [onClose]);

  useEffect(() => {
    if (isOpen) {
      document.addEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'hidden'; // منع التمرير في الخلفية
    }
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, handleKeyDown]);

  if (!isOpen) return null;

  const toolInfo = toolId ? t.tools?.[toolId] : null;
  const doc = toolInfo?.doc;

  // إغلاق النافذة عند الضغط على الخلفية السوداء
  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <div 
      className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-2xl overflow-y-auto" 
      dir={t.dir}
      onClick={handleBackdropClick}
    >
      <div className="bg-[#0a0a0a] border border-white/10 rounded-[2.5rem] w-full max-w-5xl shadow-2xl overflow-hidden flex flex-col my-auto relative animate-in zoom-in duration-300">
        
        {/* زر إغلاق عائم وفائق البروز لضمان الخروج */}
        <button 
          onClick={onClose} 
          className="absolute top-6 right-6 z-[110] p-3 bg-white/5 hover:bg-rose-600 border border-white/10 rounded-full text-white transition-all group active:scale-90"
          title={isAr ? "إغلاق (Esc)" : "Close (Esc)"}
        >
          <X size={24} className="group-hover:rotate-90 transition-transform" />
        </button>

        {/* Header */}
        <div className="px-8 py-8 border-b border-white/5 bg-[#0d0d0d]">
          <div className={`flex flex-col ${isAr ? 'items-end' : 'items-start'} gap-2 pr-12`}>
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-[#D4AF37] opacity-60">
              {isAr ? "الأداة النشطة" : "Active Utility Node"}
            </span>
            <h3 className="text-2xl md:text-3xl font-black uppercase italic tracking-tighter text-white">
              {title}
            </h3>
          </div>
        </div>

        <div className="p-6 md:p-10 overflow-y-auto custom-scrollbar flex-grow bg-black">
          <div className="max-w-4xl mx-auto space-y-12">
            
            {/* واجهة الأداة الأساسية */}
            <section className="bg-[#0d0d0d] rounded-[2.5rem] border border-white/5 p-6 md:p-10 shadow-inner relative overflow-hidden">
               <div className="absolute top-0 right-0 p-8 opacity-[0.02] pointer-events-none">
                 <Zap size={200} />
               </div>
               <div className="relative z-10">
                 {children}
               </div>
            </section>

            {/* نظام التوثيق الذكي */}
            {doc && (
              <section className="space-y-12 pb-10 border-t border-white/5 pt-12">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                   <div className="space-y-4">
                      <div className="flex items-center gap-3 text-[#D4AF37]">
                         <Info size={18} />
                         <h4 className="text-[10px] font-black uppercase tracking-widest">{t.common.about}</h4>
                      </div>
                      <p className="text-gray-400 text-sm leading-relaxed italic">{doc.about}</p>
                   </div>

                   <div className="space-y-4">
                      <div className="flex items-center gap-3 text-[#D4AF37]">
                         <Book size={18} />
                         <h4 className="text-[10px] font-black uppercase tracking-widest">{t.common.usage}</h4>
                      </div>
                      <p className="text-gray-400 text-sm leading-relaxed italic">{doc.usage}</p>
                   </div>

                   <div className="space-y-4">
                      <div className="flex items-center gap-3 text-[#D4AF37]">
                         <Target size={18} />
                         <h4 className="text-[10px] font-black uppercase tracking-widest">{t.common.benefits}</h4>
                      </div>
                      <p className="text-gray-400 text-sm leading-relaxed italic">{doc.benefits}</p>
                   </div>
                </div>

                {doc.faq && doc.faq.length > 0 && (
                  <div className="bg-white/[0.02] rounded-[2rem] border border-white/5 p-8 md:p-10">
                     <div className="flex items-center gap-3 text-[#D4AF37] mb-8">
                        <HelpCircle size={20} />
                        <h4 className="text-sm font-black uppercase tracking-[0.3em] italic">{t.common.faq}</h4>
                     </div>
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {doc.faq.map((item: any, idx: number) => (
                          <div key={idx} className="space-y-3 p-6 bg-black rounded-2xl border border-white/5 group hover:border-[#D4AF37]/30 transition-all">
                             <h5 className="text-white font-bold text-sm italic">Q: {item.q}</h5>
                             <p className="text-gray-500 text-xs leading-relaxed italic">A: {item.a}</p>
                          </div>
                        ))}
                     </div>
                  </div>
                )}
              </section>
            )}

          </div>
        </div>

        {/* Footer */}
        <div className="px-8 py-5 bg-[#0d0d0d] border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-[9px] font-black uppercase text-gray-700 tracking-widest">
           <div className="flex items-center gap-4">
             <span>{t.common.privacyProtocol}</span>
             <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_10px_#10b981]"></div>
           </div>
           <div className="flex items-center gap-3">
             <span>StrongTools MMXXV Standard Architecture</span>
             <ShieldCheck size={14} className="opacity-40" />
           </div>
        </div>
      </div>
    </div>
  );
};
