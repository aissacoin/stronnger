
import React, { useState } from 'react';
import { Youtube, Search, Copy, Check, Hash, Loader2, Target, Info, ShieldCheck, Download, AlertCircle, Sparkles, TrendingUp, Layout, Zap } from 'lucide-react';
import { GoogleGenAI, Type } from "@google/genai";
import { useLanguage } from '../LanguageContext';

export const YouTubeTagExtractor: React.FC = () => {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [tags, setTags] = useState<string[]>([]);
  const [title, setTitle] = useState('');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { t } = useLanguage();
  const langT = t.tools['yt-tag-extractor'];

  const extractTags = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!url.trim() || loading) return;

    setLoading(true);
    setError(null);
    setTags([]);
    setTitle('');

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Extract the video title and all SEO tags/keywords used for this specific YouTube video: ${url}`,
        config: {
          tools: [{ googleSearch: {} }],
          systemInstruction: "You are an Elite YouTube Growth Strategist. Return ONLY a JSON object containing 'title' and 'tags' (array of strings).",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              tags: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["title", "tags"]
          }
        }
      });

      const result = JSON.parse(response.text || "{}");
      if (result.tags) {
        setTags(result.tags);
        setTitle(result.title);
      }
    } catch (err: any) {
      setError("Error");
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (tags.length === 0) return;
    navigator.clipboard.writeText(tags.join(', '));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-20">
      <div className="bg-[#0a0a0a] border border-[var(--accent)]/30 rounded-[3rem] p-8 max-w-6xl mx-auto shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[var(--accent)]/50 to-transparent"></div>
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-12">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-red-500/10 rounded-2xl border border-red-500/20 text-red-500">
              <Youtube size={28} />
            </div>
            <div>
              <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">{langT.name}</h2>
              <p className="text-[9px] font-bold text-[var(--accent)]/40 uppercase tracking-[0.4em]">{langT.desc}</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5 space-y-10">
            <form onSubmit={extractTags} className="space-y-6">
              <div className="space-y-4">
                <label className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500 italic px-2">{langT.label}</label>
                <div className="relative group">
                   <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-700" size={20} />
                   <input 
                    type="text" 
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    className="w-full bg-black border border-white/5 rounded-2xl py-6 pl-16 pr-6 text-white text-sm font-medium outline-none focus:border-[var(--accent)]/40 transition-all shadow-inner"
                    placeholder={langT.placeholder}
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading || !url.trim()}
                className="w-full bg-[var(--accent)] text-black py-6 rounded-[2.5rem] font-black text-xl uppercase tracking-tighter italic flex items-center justify-center gap-4 hover:scale-[1.02] active:scale-95 shadow-xl transition-all disabled:opacity-20"
              >
                {loading ? (
                  <>
                    <Loader2 className="animate-spin" size={24} />
                    {langT.extracting}
                  </>
                ) : (
                  <>
                    <TrendingUp size={24} />
                    {langT.btn}
                  </>
                )}
              </button>
            </form>
          </div>

          <div className="lg:col-span-7 flex flex-col h-full space-y-6">
            <div className="flex justify-between items-center px-2">
              <label className="text-[10px] font-black uppercase tracking-[0.4em] text-[var(--accent)] italic">{langT.authority}</label>
              <button 
                onClick={handleCopy}
                disabled={tags.length === 0}
                className={`flex items-center gap-2 px-3 py-1 rounded-lg transition-all ${copied ? 'text-emerald-400' : 'text-gray-500 hover:text-white'}`}
              >
                {copied ? <Check size={14}/> : <Copy size={14}/>}
                <span className="text-[9px] font-black uppercase tracking-widest">{copied ? t.common.copied : t.common.copy}</span>
              </button>
            </div>
            
            <div className="relative flex-grow bg-black border border-white/5 rounded-[3.5rem] p-10 overflow-hidden group shadow-inner min-h-[400px]">
               {loading ? (
                 <div className="h-full flex flex-col items-center justify-center space-y-6 animate-pulse">
                    <Target size={64} className="text-[var(--accent)]" />
                    <p className="text-[10px] font-black uppercase tracking-[0.5em] text-center italic">{langT.extracting}</p>
                 </div>
               ) : tags.length > 0 ? (
                 <div className="relative z-10 space-y-8 animate-in fade-in duration-1000">
                   <div className="pb-6 border-b border-white/5">
                      <h4 className="text-[10px] font-black uppercase text-gray-500 tracking-[0.3em] mb-2 italic">{langT.authority}</h4>
                      <p className="text-xl font-black text-white italic tracking-tight truncate">{title}</p>
                   </div>
                   <div className="flex flex-wrap gap-3">
                     {tags.map((tag, i) => (
                       <div key={i} className="flex items-center gap-2 bg-[var(--accent)]/10 border border-[var(--accent)]/30 px-5 py-3 rounded-2xl hover:bg-[var(--accent)] hover:text-black transition-all">
                         <Hash size={12} />
                         <span className="text-xs font-black italic">{tag}</span>
                       </div>
                     ))}
                   </div>
                 </div>
               ) : (
                 <div className="h-full flex flex-col items-center justify-center opacity-10 space-y-6">
                   <Layout size={100} className="mx-auto" />
                   <p className="text-[10px] font-black uppercase tracking-[0.5em]">Awaiting Input</p>
                 </div>
               )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
