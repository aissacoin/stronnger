
import React, { useState, useRef } from 'react';
import { UserCheck, Upload, Loader2, Zap, Download, ShieldCheck, Info, Camera, Trash2, Check, UserRound } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

const BEARD_STYLES = [
  { id: 'stubble', name: 'Corporate Stubble', prompt: 'a light, neat 3-day corporate stubble' },
  { id: 'full', name: 'Sovereign Full Beard', prompt: 'a dense, perfectly groomed and shaped full beard' },
  { id: 'goatee', name: 'Professional Goatee', prompt: 'a clean, symmetric goatee with a sharp mustache' },
  { id: 'clean', name: 'Pure Shave', prompt: 'a perfectly clean-shaven face with no facial hair' }
];

export const GroomingSimulator: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [style, setStyle] = useState(BEARD_STYLES[0]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const transmute = async () => {
    if (!file || loading) return;
    setLoading(true);
    setResult(null);

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = async () => {
        const base64 = (reader.result as string).split(',')[1];
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: {
            parts: [
              { inlineData: { data: base64, mimeType: file.type } },
              { text: `Act as a professional barber. Modify this face to have ${style.prompt}. The modification must look 100% natural, matching skin tone, texture, and facial perspective. Return only the final image.` }
            ]
          }
        });

        let data = '';
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) data = part.inlineData.data;
        }
        if (data) setResult(`data:image/png;base64,${data}`);
      };
    } catch (err) { alert("Visual node sync failure."); }
    finally { setLoading(false); }
  };

  return (
    <div className="bg-[#0a0a0a] border border-blue-500/30 rounded-[3rem] p-8 max-w-5xl mx-auto shadow-2xl relative overflow-hidden">
      <div className="flex items-center gap-4 mb-10">
        <div className="p-3 bg-blue-500/10 rounded-2xl text-blue-400"><UserCheck size={28} /></div>
        <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">Facial Grooming Simulator</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        <div className="lg:col-span-5 space-y-8">
          <div onClick={() => fileInputRef.current?.click()} className="h-64 bg-black border-2 border-dashed border-white/5 rounded-[2.5rem] flex flex-col items-center justify-center cursor-pointer hover:border-blue-500/40 transition-all overflow-hidden">
            {preview ? <img src={preview} className="h-full w-full object-contain p-4" /> : <span className="text-[10px] font-black uppercase text-gray-500">Inject Profile Asset</span>}
            <input type="file" ref={fileInputRef} onChange={e => { const f = e.target.files?.[0]; if(f){ setFile(f); setPreview(URL.createObjectURL(f)); } }} className="hidden" accept="image/*" />
          </div>

          <div className="grid grid-cols-2 gap-2">
            {BEARD_STYLES.map(s => (
              <button key={s.id} onClick={() => setStyle(s)} className={`p-4 rounded-xl border text-[9px] font-black uppercase transition-all ${style.id === s.id ? 'bg-blue-600 text-white' : 'bg-white/5 text-gray-600 border-white/5'}`}>{s.name}</button>
            ))}
          </div>

          <button onClick={transmute} disabled={loading || !file} className="w-full bg-blue-600 text-white py-6 rounded-[2.5rem] font-black text-xl uppercase tracking-tighter italic flex items-center justify-center gap-4 hover:scale-[1.02] shadow-xl">
            {loading ? <Loader2 className="animate-spin" /> : <Zap />} Apply Grooming Protocol
          </button>
        </div>

        <div className="lg:col-span-7 bg-black border border-white/5 rounded-[3.5rem] p-6 flex items-center justify-center min-h-[450px]">
           {loading ? <div className="text-center space-y-4 animate-pulse"><Loader2 className="animate-spin text-blue-500 mx-auto" size={40} /><p className="text-[10px] font-black uppercase text-blue-500">Simulating Archetype...</p></div> : result ? <img src={result} className="max-w-full max-h-full rounded-2xl shadow-2xl" /> : <UserRound size={100} className="opacity-10" />}
        </div>
      </div>
    </div>
  );
};
