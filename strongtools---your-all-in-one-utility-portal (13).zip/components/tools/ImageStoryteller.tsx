
import React, { useState, useRef } from 'react';
import { MessageSquareText, Upload, Sparkles, Loader2, Copy, Check, Trash2, Zap, Info, ShieldCheck, Eye } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

export const ImageStoryteller: React.FC = () => {
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve((reader.result as string).split(',')[1]);
      reader.onerror = (error) => reject(error);
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      setPreviewUrl(URL.createObjectURL(file));
      setError(null);
      setOutput('');
    }
  };

  const narrateImage = async () => {
    if (!imageFile || loading) return;
    setLoading(true);
    setError(null);

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const base64Data = await fileToBase64(imageFile);
      const imagePart = {
        inlineData: { data: base64Data, mimeType: imageFile.type }
      };

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: { 
          parts: [
            imagePart, 
            { text: "Analyze this image and write a compelling, artistic narrative or professional marketing description for it. Focus on atmosphere, lighting, and hidden details. Return in high-fidelity prose." }
          ] 
        }
      });

      setOutput(response.text || "Vision node returned null registry.");
    } catch (err) {
      setError("Logical Synthesis Failure: The neural engine could not parse the visual data.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#0a0a0a] border border-blue-500/30 rounded-[3rem] p-8 max-w-5xl mx-auto shadow-2xl relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-blue-500/50 to-transparent"></div>
      
      <div className="flex items-center gap-4 mb-10">
        <div className="p-3 bg-blue-500/10 rounded-2xl border border-blue-500/20 text-blue-400"><MessageSquareText size={28} /></div>
        <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">AI Image Storyteller</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        <div className="space-y-6">
          <div 
            onClick={() => fileInputRef.current?.click()}
            className={`h-80 bg-black border-2 border-dashed rounded-[2.5rem] flex flex-col items-center justify-center cursor-pointer transition-all ${previewUrl ? 'border-blue-500/40' : 'border-white/5 hover:border-blue-500/40'}`}
          >
            {previewUrl ? (
              <img src={previewUrl} className="w-full h-full object-contain p-4 rounded-[2.5rem]" alt="Source" />
            ) : (
              <>
                <Upload size={48} className="text-gray-700 mb-4" />
                <span className="text-[10px] font-black uppercase text-gray-500">Inject Visual Source</span>
              </>
            )}
            <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" accept="image/*" />
          </div>
          <button onClick={narrateImage} disabled={loading || !imageFile} className="w-full bg-blue-600 text-white py-6 rounded-[2.5rem] font-black text-xl uppercase tracking-tighter italic flex items-center justify-center gap-4 hover:scale-[1.01] active:scale-95 transition-all shadow-2xl">
            {loading ? <Loader2 className="animate-spin" /> : <Sparkles />} Synthesize Narrative
          </button>
        </div>

        <div className="relative flex flex-col h-full space-y-4">
          <div className="flex justify-between items-center px-2">
            <label className="text-[10px] font-black uppercase tracking-[0.4em] text-blue-400 italic">Synthesized Manuscript</label>
            {output && (
              <button onClick={() => { navigator.clipboard.writeText(output); setCopied(true); setTimeout(()=>setCopied(false), 2000); }} className="text-gray-500 hover:text-white transition-colors">
                {copied ? <Check size={16} className="text-emerald-400" /> : <Copy size={16}/>}
              </button>
            )}
          </div>
          <div className="flex-grow bg-black/60 border border-white/5 rounded-[2.5rem] p-8 overflow-y-auto custom-scrollbar shadow-inner">
            {loading ? (
              <div className="h-full flex flex-col items-center justify-center space-y-4 opacity-40 animate-pulse">
                <Eye size={48} className="text-blue-500" />
                <p className="text-[10px] font-black uppercase tracking-[0.5em] text-center">Reading Visual Data...</p>
              </div>
            ) : output ? (
              <p className="text-sm text-gray-300 leading-relaxed italic whitespace-pre-wrap">{output}</p>
            ) : (
              <div className="h-full flex flex-col items-center justify-center opacity-10 space-y-4">
                <MessageSquareText size={64} />
                <p className="text-[10px] font-black uppercase tracking-[0.5em]">Awaiting Visual Input</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
