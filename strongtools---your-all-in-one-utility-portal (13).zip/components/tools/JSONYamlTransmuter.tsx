
import React, { useState } from 'react';
import { Braces, RefreshCw, Copy, Check, Trash2, Zap, FileCode, Layers } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

export const JSONYamlTransmuter: React.FC = () => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState<'JSONtoYAML' | 'YAMLtoJSON'>('JSONtoYAML');
  const [copied, setCopied] = useState(false);

  const transmute = async () => {
    if (!input.trim() || loading) return;
    setLoading(true);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Convert this ${mode === 'JSONtoYAML' ? 'JSON to YAML' : 'YAML to JSON'}. Return ONLY the code result. Manuscript: "${input}"`,
      });
      setOutput(response.text || '');
    } catch (e) { setOutput('Logical node sync failure.'); }
    finally { setLoading(false); }
  };

  return (
    <div className="bg-[#0a0a0a] border border-emerald-500/30 rounded-[3rem] p-8 max-w-6xl mx-auto shadow-2xl relative overflow-hidden selection:bg-emerald-500 selection:text-black">
      <div className="flex flex-col md:flex-row items-center justify-between mb-10 gap-6">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-emerald-500/10 rounded-2xl text-emerald-400"><Braces size={28} /></div>
          <div>
            <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">JSON-YAML Transmuter</h2>
            <p className="text-[9px] font-bold text-emerald-500/40 uppercase tracking-[0.4em]">Structured Data Shift Engine</p>
          </div>
        </div>
        <div className="flex bg-white/5 p-1 rounded-2xl border border-white/10">
          {(['JSONtoYAML', 'YAMLtoJSON'] as const).map(m => (
            <button key={m} onClick={() => setMode(m)} className={`px-5 py-2 rounded-xl text-[9px] font-black uppercase transition-all ${mode === m ? 'bg-emerald-600 text-white shadow-lg' : 'text-gray-500 hover:text-white'}`}>{m === 'JSONtoYAML' ? 'J ➔ Y' : 'Y ➔ J'}</button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <div className="space-y-4">
          <div className="flex justify-between items-center px-2">
            <label className="text-[10px] font-black uppercase text-gray-500 italic">Source Manuscript</label>
            <button onClick={() => setInput('')} className="text-gray-600 hover:text-rose-500 transition-colors"><Trash2 size={16}/></button>
          </div>
          <textarea value={input} onChange={e => setInput(e.target.value)} className="w-full h-80 bg-black border border-white/5 rounded-[2rem] p-6 text-white font-mono text-xs outline-none focus:border-emerald-500/40 shadow-inner resize-none" />
        </div>
        <div className="space-y-4">
          <div className="flex justify-between items-center px-2">
            <label className="text-[10px] font-black uppercase text-emerald-500 italic">Transmuted Registry</label>
            <button onClick={() => { navigator.clipboard.writeText(output); setCopied(true); setTimeout(()=>setCopied(false), 2000); }} className="text-gray-600 hover:text-white">
              {copied ? <Check size={16} className="text-emerald-400" /> : <Copy size={16}/>}
            </button>
          </div>
          <div className="w-full h-80 bg-emerald-500/5 border border-emerald-500/20 rounded-[2rem] p-6 text-gray-300 font-mono text-xs overflow-auto custom-scrollbar shadow-inner">
            {loading ? <div className="h-full flex items-center justify-center animate-pulse text-emerald-500 font-black">TRANSMUTING BITSTREAM...</div> : <pre>{output || "Awaiting archival input..."}</pre>}
          </div>
        </div>
      </div>

      <button onClick={transmute} disabled={loading || !input} className="w-full bg-emerald-600 text-black py-6 rounded-[2.5rem] font-black text-xl uppercase tracking-tighter italic flex items-center justify-center gap-4 hover:scale-[1.01] transition-all shadow-2xl">
        {loading ? <RefreshCw className="animate-spin" /> : <Zap />} Execute Transmutation
      </button>
    </div>
  );
};
