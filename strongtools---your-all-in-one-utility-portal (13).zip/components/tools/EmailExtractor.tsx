import React, { useState, useEffect } from 'react';
import { Mail, Copy, Trash2, Check, ShieldCheck, Zap, Info, FileSearch } from 'lucide-react';
import { useLanguage } from '../LanguageContext';

export const EmailExtractor: React.FC = () => {
  const [input, setInput] = useState('');
  const [emails, setEmails] = useState<string[]>([]);
  const [copied, setCopied] = useState(false);
  const { t, language } = useLanguage();
  const isAr = language === 'ar';
  const langT = t.tools['email-extractor'];

  const [options, setOptions] = useState({
    removeDuplicates: true,
    alphabetical: true
  });

  const extractEmails = () => {
    if (!input.trim()) {
      setEmails([]);
      return;
    }
    const regex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/gi;
    let matches = input.match(regex) || [];
    matches = matches.map(e => e.toLowerCase());
    if (options.removeDuplicates) matches = Array.from(new Set(matches));
    if (options.alphabetical) matches.sort();
    setEmails(matches);
  };

  useEffect(() => {
    extractEmails();
  }, [input, options]);

  const handleCopy = () => {
    if (emails.length === 0) return;
    navigator.clipboard.writeText(emails.join('\n'));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-12" dir={t.dir}>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
        <div className="space-y-4">
          <div className="flex justify-between items-center px-2">
            <label className="text-[10px] font-black uppercase text-gray-500 italic">{langT.internal.label}</label>
            <button onClick={() => setInput('')} className="text-gray-600 hover:text-rose-400 transition-colors"><Trash2 size={14}/></button>
          </div>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className={`w-full h-80 bg-black border border-white/5 rounded-[2rem] p-6 text-white text-sm outline-none focus:border-[#D4AF37]/40 shadow-inner custom-scrollbar ${isAr ? 'text-right' : 'text-left'}`}
            placeholder={langT.internal.placeholder}
          />
        </div>

        <div className="space-y-4">
          <div className="flex justify-between items-center px-2">
            <label className="text-[10px] font-black uppercase text-[#D4AF37] italic">{langT.internal.result} ({emails.length})</label>
            <button 
              onClick={handleCopy}
              disabled={emails.length === 0}
              className={`flex items-center gap-2 px-3 py-1 rounded-lg transition-all ${copied ? 'text-emerald-400' : 'text-[#D4AF37] hover:text-white'}`}
            >
              {copied ? <Check size={14}/> : <Copy size={14}/>}
              <span className="text-[9px] font-black uppercase">{copied ? t.common.copied : langT.internal.btnCopy}</span>
            </button>
          </div>
          <div className={`w-full h-80 bg-[#D4AF37]/5 border border-[#D4AF37]/20 rounded-[2rem] p-6 text-[#D4AF37] font-mono text-xs overflow-y-auto custom-scrollbar italic shadow-inner ${isAr ? 'text-right' : 'text-left'}`}>
            {emails.length > 0 ? (
              <div className="space-y-1">
                {emails.map((e, i) => <div key={i} className="py-1 border-b border-white/5 last:border-0">{e}</div>)}
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center opacity-10">
                <FileSearch size={48} />
              </div>
            )}
          </div>
        </div>
      </div>

      {isAr && (
        <div className="max-w-5xl mx-auto p-12 bg-white/[0.01] border-2 border-dashed border-white/10 rounded-[4rem] relative overflow-hidden group">
           <Info className="absolute -bottom-10 -right-10 opacity-[0.03] text-white rotate-12" size={300} />
           <div className="relative z-10 space-y-6 text-right">
              <div className="flex items-center justify-end gap-3 text-[#D4AF37]">
                 <h3 className="text-2xl font-black uppercase italic tracking-tighter">أداة حصاد البريد الإلكتروني</h3>
                 <Zap size={24} />
              </div>
              <p className="text-lg text-gray-400 leading-relaxed italic">
                "مستخرج الإيميلات هو أداة تقنية متقدمة تستخدم خوارزميات التعابير النمطية (Regex) لمسح كتل النصوص الضخمة واستنباط عناوين البريد الإلكتروني الصحيحة منها. هذه الأداة مثالية للمسوقين والمطورين الذين يحتاجون لتنظيف قوائم المراسلات أو استخراج بيانات التواصل من ملفات السجلات (Logs) والوثائق الطويلة بسرعة ودقة."
              </p>
           </div>
        </div>
      )}
    </div>
  );
};