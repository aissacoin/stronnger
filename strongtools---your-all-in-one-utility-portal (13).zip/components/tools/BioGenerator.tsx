
import React, { useState } from 'react';
import { Send, Copy, Check, Sparkles, Loader2, UserCheck, Zap, ShieldCheck } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

export const BioGenerator: React.FC = () => {
  const [desc, setDesc] = useState('');
  const [tone, setTone] = useState('Professional');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const generateBio = async () => {
    if (!desc.trim() || loading) return;
    setLoading(true);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Generate a short, viral social media bio for: "${desc}". Tone: ${tone}. Include relevant emojis and a clear CTA if applicable. Maximum 150 characters.`,
      });
      setOutput(response.text || '');
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  return (
    <div className="bg-[#0a0a0a] border border-[#D4AF37]/30 rounded-[3rem] p-8 max-w-4xl mx-auto shadow-2xl relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#D4AF37]/50 to-transparent"></div>
      <div className="flex items-center gap-4 mb-8">
        <div className="p-3 bg-[#D4AF37]/10 rounded-2xl text-[#D4AF37]"><UserCheck size={28} /></div>
        <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">AI Bio Architect</h2>
      </div>

      <div className="space-y-6">
        <textarea 
          value={desc} 
          onChange={e => setDesc(e.target.value)} 
          className="w-full h-32 bg-black border border-white/5 rounded-2xl p-6 text-white outline-none focus:border-[#D4AF37]/40" 
          placeholder="Describe your essence (e.g. Architect from Riyadh who loves coffee and coding)..."
        />
        
        <div className="flex gap-2">
          {['Professional', 'Witty', 'Creative', 'Minimalist'].map(t => (
            <button key={t} onClick={() => setTone(t)} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${tone === t ? 'bg-[#D4AF37] text-black' : 'bg-white/5 text-gray-500'}`}>{t}</button>
          ))}
        </div>

        <button onClick={generateBio} disabled={loading} className="w-full bg-[#D4AF37] text-black py-5 rounded-2xl font-black uppercase flex items-center justify-center gap-2">
          {loading ? <Loader2 className="animate-spin" /> : <Sparkles />} Generate Identity
        </button>

        {output && (
          <div className="p-6 bg-white/5 rounded-2xl border border-white/10 relative group">
            <p className="text-lg text-white italic">"{output}"</p>
            <button onClick={() => { navigator.clipboard.writeText(output); setCopied(true); setTimeout(()=>setCopied(false), 2000); }} className="absolute top-4 right-4 text-[#D4AF37]">
              {copied ? <Check size={18}/> : <Copy size={18}/>}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
