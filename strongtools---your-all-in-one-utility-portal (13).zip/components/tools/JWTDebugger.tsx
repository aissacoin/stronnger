
import React, { useState, useEffect } from 'react';
import { Unlock, Copy, Check, ShieldAlert, ShieldCheck, Zap } from 'lucide-react';

export const JWTDebugger: React.FC = () => {
  const [token, setToken] = useState('');
  const [header, setHeader] = useState('');
  const [payload, setPayload] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (!token) { setHeader(''); setPayload(''); setError(''); return; }
    try {
      const parts = token.split('.');
      if (parts.length !== 3) throw new Error("Invalid Format");
      setHeader(JSON.stringify(JSON.parse(atob(parts[0].replace(/-/g, '+').replace(/_/g, '/'))), null, 2));
      setPayload(JSON.stringify(JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/'))), null, 2));
      setError('');
    } catch (e) {
      setError('Invalid JWT Manuscript detected.');
    }
  }, [token]);

  return (
    <div className="bg-[#0a0a0a] border border-rose-500/30 rounded-[3rem] p-8 max-w-5xl mx-auto shadow-2xl relative overflow-hidden selection:bg-rose-500 selection:text-white">
      <div className="flex items-center gap-4 mb-8">
        <div className="p-3 bg-rose-500/10 rounded-2xl text-rose-500"><Unlock size={28} /></div>
        <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">JWT Manuscript Debugger</h2>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-4">
          <label className="text-[10px] font-black uppercase text-gray-500 px-2 italic tracking-widest">Encoded JWS/JWT</label>
          <textarea value={token} onChange={e => setToken(e.target.value)} className="w-full h-80 bg-black border border-white/5 rounded-[2rem] p-8 text-rose-400 font-mono text-xs outline-none focus:border-rose-500/40 shadow-inner resize-none" placeholder="Paste token here..." />
        </div>
        <div className="space-y-4 flex flex-col h-full">
          <div className="p-6 bg-white/[0.02] border border-white/5 rounded-3xl flex-1 overflow-auto custom-scrollbar">
            <span className="text-[10px] font-black text-rose-500 uppercase tracking-widest block mb-4 italic">Registry Header</span>
            <pre className="text-[11px] text-gray-400 font-mono">{header || "..."}</pre>
          </div>
          <div className="p-6 bg-white/[0.02] border border-white/5 rounded-3xl flex-[2] overflow-auto custom-scrollbar">
             <span className="text-[10px] font-black text-rose-500 uppercase tracking-widest block mb-4 italic">Payload Claims</span>
             <pre className="text-[11px] text-gray-300 font-mono">{payload || "..."}</pre>
          </div>
          {error && <p className="text-rose-500 text-[10px] font-black italic animate-pulse text-center">[{error}]</p>}
        </div>
      </div>
    </div>
  );
};
