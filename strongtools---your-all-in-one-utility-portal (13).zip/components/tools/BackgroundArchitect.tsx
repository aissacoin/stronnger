
import React, { useState, useRef } from 'react';
import { Mountain, Upload, Loader2, Sparkles, Download, ShieldCheck, Zap, Image as ImageIcon, Trash2, Wand2 } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

export const BackgroundArchitect: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('');
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve((reader.result as string).split(',')[1]);
      reader.onerror = (error) => reject(error);
    });
  };

  const synthesizeBackground = async () => {
    if (!file || !prompt.trim() || loading) return;
    setLoading(true);
    setResult(null);

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const base64 = await fileToBase64(file);
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [
            { inlineData: { data: base64, mimeType: file.type } },
            { text: `Keep the main subject exactly as it is. Replace the background with: "${prompt}". The new background should be professional, atmospheric, and have lighting that matches the subject perfectly. Return the combined final image.` }
          ]
        }
      });

      let base64Data = '';
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          base64Data = part.inlineData.data;
          break;
        }
      }
      if (base64Data) setResult(`data:image/png;base64,${base64Data}`);
    } catch (err) {
      alert("Neural desync: Background synthesis failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#0a0a0a] border border-orange-500/30 rounded-[3rem] p-8 max-w-6xl mx-auto shadow-2xl relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-orange-500/50 to-transparent"></div>
      
      <div className="flex items-center gap-4 mb-10">
        <div className="p-3 bg-orange-500/10 rounded-2xl text-orange-400"><Mountain size={28} /></div>
        <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">AI Background Architect</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        <div className="lg:col-span-5 space-y-8">
          <div onClick={() => fileInputRef.current?.click()} className="h-64 bg-black border-2 border-dashed border-white/5 rounded-[2.5rem] flex flex-col items-center justify-center cursor-pointer hover:border-orange-500/40 transition-all overflow-hidden">
            {preview ? <img src={preview} className="h-full w-full object-contain p-4" /> : <span className="text-[10px] font-black uppercase text-gray-500">Inject Subject Profile</span>}
            <input type="file" ref={fileInputRef} onChange={e => { const f = e.target.files?.[0]; if(f){ setFile(f); setPreview(URL.createObjectURL(f)); } }} className="hidden" accept="image/*" />
          </div>

          <div className="space-y-4">
             <label className="text-[10px] font-black uppercase text-gray-500 italic px-2">Environment Directive (Prompt)</label>
             <textarea 
              value={prompt} 
              onChange={e => setPrompt(e.target.value)} 
              className="w-full h-32 bg-black border border-white/5 rounded-2xl p-4 text-white text-sm outline-none focus:border-orange-500/40 transition-all"
              placeholder="e.g. A luxury minimalist studio with soft sunset lighting..."
             />
          </div>

          <button onClick={synthesizeBackground} disabled={loading || !file || !prompt} className="w-full bg-orange-600 text-white py-6 rounded-[2.5rem] font-black text-xl uppercase tracking-tighter italic flex items-center justify-center gap-4 hover:scale-[1.02] shadow-xl">
            {loading ? <Loader2 className="animate-spin" /> : <Wand2 />} Forge Environment
          </button>
        </div>

        <div className="lg:col-span-7 bg-black border border-white/5 rounded-[3.5rem] p-6 flex items-center justify-center min-h-[450px]">
           {loading ? <div className="text-center space-y-4 animate-pulse"><Loader2 className="animate-spin text-orange-500 mx-auto" size={48} /><p className="text-[10px] font-black uppercase text-orange-500">Architecting Space...</p></div> : result ? <img src={result} className="max-w-full max-h-full rounded-2xl shadow-2xl" /> : <ImageIcon size={100} className="opacity-10" />}
        </div>
      </div>
    </div>
  );
};
