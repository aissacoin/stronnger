
import React, { useState } from 'react';
import { Calendar, Clock, Sparkles, Loader2, Trash2, Check, Zap, Info } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

export const ExamPlanner: React.FC = () => {
  const [exams, setExams] = useState('');
  const [days, setDays] = useState('7');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);

  const generatePlan = async () => {
    if (!exams.trim() || loading) return;
    setLoading(true);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Architect a highly efficient study schedule for these exams: "${exams}". I have ${days} days left. 
        Focus on: High-intensity intervals (Pomodoro), prioritized difficulty, and mandatory revision nodes. 
        Format: Day-by-Day schedule with clear time slots. Return in professional English.`,
      });
      setOutput(response.text || '');
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  return (
    <div className="bg-[#0a0a0a] border border-amber-500/30 rounded-[3rem] p-8 max-w-4xl mx-auto shadow-2xl relative overflow-hidden">
      <div className="flex items-center gap-4 mb-8">
        <div className="p-3 bg-amber-500/10 rounded-2xl text-amber-500"><Calendar size={28} /></div>
        <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">Exam Meridian Planner</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="space-y-4">
          <label className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500 italic px-2">Subjects & Difficulty</label>
          <textarea 
            value={exams} onChange={e => setExams(e.target.value)}
            className="w-full h-32 bg-black border border-white/5 rounded-2xl p-5 text-white outline-none focus:border-amber-500/40 transition-all"
            placeholder="e.g. Calculus (Hard), Physics (Medium), History (Easy)..."
          />
        </div>
        <div className="space-y-4">
          <label className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500 italic px-2">Temporal Limit (Days)</label>
          <input 
            type="number" value={days} onChange={e => setDays(e.target.value)}
            className="w-full bg-black border border-white/5 rounded-2xl p-5 text-white font-black text-2xl outline-none focus:border-amber-500/40"
          />
          <button onClick={generatePlan} disabled={loading} className="w-full bg-amber-600 text-white py-5 rounded-2xl font-black uppercase flex items-center justify-center gap-2 hover:bg-amber-500">
            {loading ? <Loader2 className="animate-spin" /> : <Sparkles />} Synthesize Schedule
          </button>
        </div>
      </div>

      {output && (
        <div className="p-10 bg-white/[0.02] rounded-[2.5rem] border border-amber-500/20 max-h-96 overflow-y-auto custom-scrollbar">
          <div className="prose prose-invert prose-sm text-gray-300 italic whitespace-pre-wrap leading-relaxed">
            {output}
          </div>
        </div>
      )}
    </div>
  );
};
