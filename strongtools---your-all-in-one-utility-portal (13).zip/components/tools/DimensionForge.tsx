import React, { useState, useRef } from 'react';
import { Box, Upload, Download, Trash2, ShieldCheck, Zap, Info, Image as ImageIcon, Loader2, Check, Sparkles, Camera, Layers } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { useLanguage } from '../LanguageContext';

type ForgeMode = '3D_RENDER' | 'ULTRA_4K' | 'FLAT_2D';
type AspectRatio = '1:1' | '16:9' | '9:16' | '4:3';

export const DimensionForge: React.FC = () => {
  const { t, language } = useLanguage();
  const isAr = language === 'ar';
  
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [mode, setMode] = useState<ForgeMode>('3D_RENDER');
  const [ratio, setRatio] = useState<AspectRatio>('1:1');
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState('');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = e.target.files?.[0];
    if (uploadedFile) {
      setFile(uploadedFile);
      setPreview(URL.createObjectURL(uploadedFile));
      setResult(null);
      setStatus('');
    }
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve((reader.result as string).split(',')[1]);
      reader.onerror = (error) => reject(error);
    });
  };

  const forgeDimensions = async () => {
    if (!file || loading) return;
    setLoading(true);
    setStatus(isAr ? 'جاري تصنيع الأبعاد...' : 'Synthesizing Dimensions...');
    
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const base64Data = await fileToBase64(file);
      const promptMap = {
        '3D_RENDER': "Transform this image into a hyper-realistic 3D render with depth and shadows. Professional product photography look.",
        'ULTRA_4K': "Enhance this image to Ultra-HD 4K quality, sharpen edges, and remove artifacts.",
        'FLAT_2D': "Simplify this image into a clean, minimalist 2D vector illustrative style."
      };

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [
            { inlineData: { data: base64Data, mimeType: file.type } },
            { text: promptMap[mode] }
          ]
        },
        config: { imageConfig: { aspectRatio: ratio } }
      });

      let forgedBase64 = '';
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) forgedBase64 = part.inlineData.data;
      }

      if (forgedBase64) setResult(`data:image/png;base64,${forgedBase64}`);
      setStatus('');
    } catch (err) { setStatus('Error'); }
    finally { setLoading(false); }
  };

  return (
    <div className="space-y-12" dir={t.dir}>
      <div className="bg-[#0a0a0a] border border-[#D4AF37]/30 rounded-[3rem] p-8 max-w-7xl mx-auto shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent"></div>
        
        <div className="flex flex-col xl:flex-row items-center justify-between gap-8 mb-12">
          <div className="flex items-center gap-4">
            <div className="p-4 bg-[#D4AF37]/10 rounded-[1.5rem] border border-[#D4AF37]/20 text-[#D4AF37]">
              <Camera size={32} />
            </div>
            <div className={isAr ? 'text-right' : 'text-left'}>
              <h2 className="text-3xl font-black text-white uppercase italic tracking-tighter">{isAr ? 'مصنع الأبعاد الذكي' : '3D Dimension Forge'}</h2>
              <p className="text-[10px] font-bold text-[#D4AF37]/40 uppercase tracking-[0.5em] mt-2">{isAr ? 'توليد بصري متطور للمنتجات' : 'Neural Visual Synthesis Core'}</p>
            </div>
          </div>

          <div className="flex bg-white/5 p-1 rounded-2xl border border-white/10">
            {(['3D_RENDER', 'ULTRA_4K', 'FLAT_2D'] as ForgeMode[]).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`px-6 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${mode === m ? 'bg-[#D4AF37] text-black shadow-lg' : 'text-gray-500 hover:text-white'}`}
              >
                {m === '3D_RENDER' ? (isAr ? 'مجسم 3D' : '3D Render') : m === 'ULTRA_4K' ? (isAr ? 'دقة 4K' : 'Ultra 4K') : (isAr ? 'تخطيط 2D' : 'Vector 2D')}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          <div className="lg:col-span-4 space-y-8 border-r border-white/5 pr-8">
            <div className="space-y-4">
              <label className="text-[10px] font-black uppercase text-gray-500 italic px-2">{isAr ? '1. ارفع صورة المصدر' : '1. Ingest Master Image'}</label>
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="group relative cursor-pointer h-48 bg-black border-2 border-dashed border-white/5 rounded-[2.5rem] flex flex-col items-center justify-center gap-4 hover:border-[#D4AF37]/40 transition-all overflow-hidden"
              >
                {preview ? <img src={preview} className="w-full h-full object-contain p-4 opacity-70" /> : <Upload size={32} className="text-gray-700" />}
                <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" accept="image/*" />
              </div>
            </div>

            <button
              onClick={forgeDimensions}
              disabled={loading || !file}
              className="w-full bg-[#D4AF37] text-black py-6 rounded-[2.5rem] font-black text-xl uppercase tracking-tighter italic flex items-center justify-center gap-4 hover:scale-[1.02] transition-all shadow-xl"
            >
              {loading ? <Loader2 className="animate-spin" /> : <Sparkles />}
              {isAr ? 'ابدأ التصنيع' : 'Forge Asset'}
            </button>
          </div>

          <div className="lg:col-span-8 flex flex-col h-full space-y-6">
            <div className="relative flex-grow bg-black/60 border border-white/5 rounded-[3.5rem] p-6 flex items-center justify-center min-h-[500px] overflow-hidden group shadow-inner">
               {result ? (
                 <div className="relative z-10 w-full h-full flex flex-col items-center justify-center animate-in fade-in zoom-in">
                    <img src={result} className="max-w-full max-h-full rounded-2xl shadow-2xl" />
                    <button onClick={() => { const a = document.createElement('a'); a.href = result; a.download = 'forged_3d.png'; a.click(); }} className="mt-6 px-8 py-3 bg-emerald-600 text-white rounded-xl font-black text-xs uppercase tracking-widest">{isAr ? 'تحميل الملف' : 'Download File'}</button>
                 </div>
               ) : <ImageIcon size={100} className="opacity-10" />}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-12 bg-white/[0.01] border-2 border-dashed border-white/10 rounded-[4rem] relative overflow-hidden group">
         <Info className="absolute -bottom-10 -right-10 opacity-[0.03] text-white rotate-12" size={300} />
         <div className="relative z-10 space-y-6 text-right">
            <div className="flex items-center justify-end gap-3 text-[#D4AF37]">
               <h3 className="text-2xl font-black uppercase italic tracking-tighter">{isAr ? 'كيف تعمل تكنولوجيا مصنع الأبعاد؟' : 'The Tech Protocol'}</h3>
               <Layers size={24} />
            </div>
            <p className="text-lg text-gray-400 leading-relaxed italic">
              {isAr ? 
                "يستخدم مصنع الأبعاد نظام الذكاء الاصطناعي السيادي لتحليل العمق الهندسي للصورة المسطحة. يقوم المحرك بتخمين الزوايا المخفية وإضافة إضاءة حجمية (Volumetric Lighting) وتصحيح الظلال ليعطيك إيحاءً بأن المنتج تم تصويره بكاميرا احترافية 360 درجة. يمكنك أيضاً تحويل الصور القديمة إلى دقة 4K فائقة الوضوح لاستخدامها في متاجرك الإلكترونية الاحترافية." 
                : "The Dimension Forge utilizes sovereign visual logic to analyze geometry and depth..."}
            </p>
         </div>
      </div>
    </div>
  );
};