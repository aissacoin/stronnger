import React, { useState, useEffect, useCallback } from 'react';
import { Hash, Copy, Check, Trash2, Download, ShieldCheck, Zap, Info, FileDigit, ListFilter, Scissors, Type, ArrowRight, Save } from 'lucide-react';
import { useLanguage } from '../LanguageContext';

export const NumberExtractor: React.FC = () => {
  const [input, setInput] = useState('');
  const [extractedNumbers, setExtractedNumbers] = useState<string[]>([]);
  const [copiedType, setCopiedType] = useState<'nums' | 'text' | null>(null);
  const [separator, setSeparator] = useState<string>('\n');
  const { t, language } = useLanguage();
  const isAr = language === 'ar';

  const [options, setOptions] = useState({
    removeDuplicates: false,
    sortNumeric: false,
    keepDecimals: true
  });

  const extractLogic = useCallback(() => {
    if (!input.trim()) {
      setExtractedNumbers([]);
      return;
    }
    const regex = options.keepDecimals ? /-?\d+(\.\d+)?/g : /\d+/g;
    let matches = input.match(regex) || [];
    if (options.removeDuplicates) matches = Array.from(new Set(matches));
    if (options.sortNumeric) matches.sort((a, b) => parseFloat(a) - parseFloat(b));
    setExtractedNumbers(matches);
  }, [input, options]);

  useEffect(() => {
    extractLogic();
  }, [extractLogic]);

  const handleCopy = (type: 'nums' | 'text') => {
    const textToCopy = type === 'nums' ? extractedNumbers.join(separator) : input;
    if (!textToCopy) return;
    navigator.clipboard.writeText(textToCopy);
    setCopiedType(type);
    setTimeout(() => setCopiedType(null), 2000);
  };

  const handleDownload = () => {
    if (extractedNumbers.length === 0) return;
    const content = extractedNumbers.join(separator);
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Extracted_Numbers_${Date.now()}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-12" dir={t.dir}>
      <div className="bg-[#0a0a0a] border border-[#D4AF37]/30 rounded-[3rem] p-8 max-w-6xl mx-auto shadow-2xl relative overflow-hidden selection:bg-[#D4AF37] selection:text-black">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#D4AF37]/50 to-transparent"></div>
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-10">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-[#D4AF37]/10 rounded-2xl border border-[#D4AF37]/20 text-[#D4AF37]">
              <FileDigit size={28} />
            </div>
            <div className={isAr ? 'text-right' : 'text-left'}>
              <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">{isAr ? 'مستخرج الأرقام' : 'Number Extractor'}</h2>
              <p className="text-[9px] font-bold text-[#D4AF37]/40 uppercase tracking-[0.4em]">{isAr ? 'وحدة حصاد البيانات الرقمية' : 'Numerical Data Harvesting Node'}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 px-5 py-2 bg-emerald-500/5 border border-emerald-500/20 rounded-xl">
             <ShieldCheck size={14} className="text-emerald-400" />
             <span className="text-[9px] font-black uppercase tracking-widest text-emerald-400/60">{isAr ? 'تم التحقق من المنطق 2025' : 'Logic Verified MMXXV'}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          <div className="lg:col-span-4 space-y-6">
            <label className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500 italic px-2">{isAr ? 'بروتوكول الاستخراج' : 'Extraction Protocol'}</label>
            <div className="grid grid-cols-1 gap-2">
              <button
                onClick={() => setOptions(prev => ({ ...prev, keepDecimals: !prev.keepDecimals }))}
                className={`flex items-center justify-between p-4 rounded-2xl border transition-all ${options.keepDecimals ? 'bg-[#D4AF37]/10 border-[#D4AF37] text-[#D4AF37]' : 'bg-white/5 border-white/5 text-gray-500'}`}
              >
                <span className="text-[10px] font-black uppercase tracking-widest">{isAr ? 'تضمين الكسور' : 'Include Decimals'}</span>
                <div className={`w-1.5 h-1.5 rounded-full ${options.keepDecimals ? 'bg-[#D4AF37]' : 'bg-white/10'}`}></div>
              </button>
              <button
                onClick={() => setOptions(prev => ({ ...prev, removeDuplicates: !prev.removeDuplicates }))}
                className={`flex items-center justify-between p-4 rounded-2xl border transition-all ${options.removeDuplicates ? 'bg-[#D4AF37]/10 border-[#D4AF37] text-[#D4AF37]' : 'bg-white/5 border-white/5 text-gray-500'}`}
              >
                <span className="text-[10px] font-black uppercase tracking-widest">{isAr ? 'الفريد فقط' : 'Unique Only'}</span>
                <div className={`w-1.5 h-1.5 rounded-full ${options.removeDuplicates ? 'bg-[#D4AF37]' : 'bg-white/10'}`}></div>
              </button>
            </div>

            <div className="space-y-3 pt-4">
              <label className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500 italic px-2">{isAr ? 'فاصل المخرجات' : 'Output Separator'}</label>
              <div className="flex bg-white/5 p-1 rounded-xl border border-white/10">
                {[
                  { label: isAr ? 'سطر' : 'Line', val: '\n' },
                  { label: isAr ? 'فاصلة' : 'Comma', val: ', ' },
                  { label: isAr ? 'مسافة' : 'Space', val: ' ' }
                ].map((s) => (
                  <button 
                    key={s.label}
                    onClick={() => setSeparator(s.val)}
                    className={`flex-1 py-2 rounded-lg text-[9px] font-black uppercase transition-all ${separator === s.val ? 'bg-[#D4AF37] text-black shadow-md' : 'text-gray-500'}`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-8 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               <div className="space-y-3">
                  <div className="flex justify-between items-center px-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500 italic">{isAr ? 'النص المصدر' : 'Source Text'}</label>
                  </div>
                  <textarea 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    className={`w-full h-80 bg-black border border-white/5 rounded-[2.5rem] p-6 text-white text-sm outline-none focus:border-[#D4AF37]/40 transition-all placeholder-white/5 resize-none shadow-inner custom-scrollbar ${isAr ? 'text-right' : 'text-left'}`}
                    placeholder={isAr ? "الصق النص الذي يحتوي على أرقام هنا..." : "Paste text with numbers..."}
                  />
               </div>
               <div className="space-y-3">
                  <div className="flex justify-between items-center px-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.4em] text-[#D4AF37] italic">{isAr ? 'الأرقام المستخرجة' : 'Extracted Digits'}</label>
                  </div>
                  <div className={`w-full h-80 bg-[#D4AF37]/5 border border-[#D4AF37]/20 rounded-[2.5rem] p-6 text-[var(--accent)] font-mono text-sm overflow-y-auto custom-scrollbar italic shadow-inner ${isAr ? 'text-right' : 'text-left'}`}>
                    {extractedNumbers.length > 0 ? extractedNumbers.join(separator) : <span className="opacity-10 italic">{isAr ? 'في انتظار الحصاد...' : 'Awaiting harvesting...'}</span>}
                  </div>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};