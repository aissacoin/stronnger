import React, { useState, useEffect } from 'react';
import { QrCode, Download, Info, Zap, ShieldCheck } from 'lucide-react';
import { useLanguage } from '../LanguageContext';

export const QRGenerator: React.FC = () => {
  const { t, language } = useLanguage();
  const isAr = language === 'ar';
  const langT = t.tools['qr-gen'];
  
  const [text, setText] = useState('');
  const [qrUrl, setQrUrl] = useState('');

  useEffect(() => {
    if (text.trim()) {
      const encoded = encodeURIComponent(text);
      setQrUrl(`https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encoded}&color=000000&bgcolor=ffffff&margin=10`);
    } else {
      setQrUrl('');
    }
  }, [text]);

  const handleDownload = () => {
    if (!qrUrl) return;
    const link = document.createElement('a');
    link.href = qrUrl;
    link.download = isAr ? `كود_QR_سيادي.png` : `Sovereign_QR.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-12" dir={t.dir}>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-10 max-w-5xl mx-auto">
        <div className="space-y-6">
          <label className="text-[10px] font-black uppercase text-gray-500 italic px-2">{langT.internal.label}</label>
          <textarea 
            value={text}
            onChange={(e) => setText(e.target.value)}
            className={`w-full h-48 bg-black border border-white/5 rounded-[2.5rem] p-6 text-white text-sm outline-none focus:border-[#D4AF37]/40 transition-all placeholder-white/5 resize-none italic shadow-inner ${isAr ? 'text-right' : 'text-left'}`}
            placeholder={langT.internal.placeholder}
          />
          <button
            onClick={handleDownload}
            disabled={!qrUrl}
            className="w-full bg-[#D4AF37] text-black py-5 rounded-2xl font-black uppercase text-[10px] tracking-widest hover:scale-[1.02] transition-all disabled:opacity-20 flex items-center justify-center gap-3"
          >
            <Download size={18}/> {langT.internal.btnDownload}
          </button>
        </div>

        <div className="flex flex-col items-center justify-center bg-white/5 border border-white/5 rounded-[3rem] p-10 min-h-[300px]">
           {qrUrl ? (
             <img src={qrUrl} className="w-48 h-48 rounded-xl shadow-2xl animate-in zoom-in duration-500" alt="QR Code" />
           ) : (
             <div className="text-center opacity-10 space-y-4">
               <QrCode size={80} className="mx-auto" />
             </div>
           )}
        </div>
      </div>

      {isAr && (
        <div className="max-w-5xl mx-auto p-12 bg-white/[0.01] border-2 border-dashed border-white/10 rounded-[4rem] relative overflow-hidden group">
           <Info className="absolute -bottom-10 -right-10 opacity-[0.03] text-white rotate-12" size={300} />
           <div className="relative z-10 space-y-6 text-right">
              <div className="flex items-center justify-end gap-3 text-[#D4AF37]">
                 <h3 className="text-2xl font-black uppercase italic tracking-tighter">تقنية كود الاستجابة السريعة</h3>
                 <Zap size={24} />
              </div>
              <p className="text-lg text-gray-400 leading-relaxed italic">
                {langT.explanation}
              </p>
           </div>
        </div>
      )}
    </div>
  );
};