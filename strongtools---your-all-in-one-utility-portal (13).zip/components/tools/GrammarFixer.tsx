import React, { useState } from 'react';
import { Languages, Sparkles, Loader2, Copy, Check, Trash2, Wand2, ShieldCheck } from 'lucide-react';
import { GoogleGenAI, Type } from "@google/genai";
import { useLanguage } from '../LanguageContext';

export const GrammarFixer: React.FC = () => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [explanation, setExplanation] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const { t, language } = useLanguage();
  const langT = t.tools['grammar-fixer'];
  const isAr = language === 'ar';

  const fixGrammar = async () => {
    if (!input.trim() || loading) return;
    setLoading(true);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Fix the following text. Language: automatic. Output: JSON.\nTEXT: "${input}"`,
        config: {
          systemInstruction: "You are an expert polyglot editor. Fix grammar and spelling. Return JSON object with 'fixedText' and 'changesSummary'.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              fixedText: { type: Type.STRING },
              changesSummary: { type: Type.STRING }
            },
            required: ["fixedText", "changesSummary"]
          }
        }
      });

      const data = JSON.parse(response.text || "{}");
      setOutput(data.fixedText);
      setExplanation(data.changesSummary);
    } catch (err) {
      setOutput("Error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8" dir={t.dir}>
      <div className="bg-[#0a0a0a] border border-[#D4AF37]/30 rounded-[3rem] p-8 max-w-4xl mx-auto shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-center gap-6 mb-8">
          <div className="p-3 bg-indigo-500/10 rounded-2xl border border-indigo-500/20 text-indigo-400">
            <Languages size={28} />
          </div>
          <div className={isAr ? 'text-right' : 'text-left'}>
            <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">{langT.name}</h2>
            <p className="text-[9px] font-bold text-[#D4AF37]/40 uppercase tracking-[0.4em]">{langT.desc}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <div className="space-y-4">
            <div className="flex justify-between items-center px-2">
              <label className="text-[10px] font-black uppercase text-gray-500 italic">{langT.internal.original}</label>
              <button onClick={() => setInput('')} className="text-gray-600 hover:text-rose-400"><Trash2 size={14}/></button>
            </div>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className={`w-full h-72 bg-black border border-white/5 rounded-[2rem] p-6 text-white text-sm outline-none focus:border-[#D4AF37]/40 shadow-inner ${isAr ? 'text-right' : 'text-left'}`}
              placeholder={isAr ? "الصق النص المراد تصحيحه هنا..." : "Paste text here..."}
            />
          </div>

          <div className="space-y-4">
            <div className="flex justify-between items-center px-2">
              <label className="text-[10px] font-black uppercase text-[#D4AF37] italic">{langT.internal.corrected}</label>
              <button 
                onClick={() => { navigator.clipboard.writeText(output); setCopied(true); setTimeout(()=>setCopied(false), 2000); }}
                disabled={!output}
                className="text-[#D4AF37] hover:text-white"
              >
                {copied ? <Check size={14}/> : <Copy size={14}/>}
              </button>
            </div>
            <div className={`relative w-full h-72 bg-[#D4AF37]/5 border border-[#D4AF37]/20 rounded-[2rem] p-6 text-gray-200 text-sm overflow-y-auto italic shadow-inner ${isAr ? 'text-right' : 'text-left'}`}>
              {loading ? (
                <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                  <Loader2 className="animate-spin text-[#D4AF37]" size={32} />
                </div>
              ) : output || (isAr ? "في انتظار المعالجة..." : "Awaiting transmission...")}
            </div>
          </div>
        </div>

        <button
          onClick={fixGrammar}
          disabled={loading || !input.trim()}
          className="w-full bg-[#D4AF37] text-black py-6 rounded-[2.5rem] font-black text-xl uppercase italic flex items-center justify-center gap-4 hover:scale-[1.01] active:scale-95 shadow-xl disabled:opacity-20"
        >
          {loading ? <Loader2 className="animate-spin" /> : <Wand2 />}
          {langT.internal.btn}
        </button>
      </div>
    </div>
  );
};