
import React, { useState, useEffect } from 'react';
import { Twitter, Layout, Scissors, Copy, Check, ShieldCheck } from 'lucide-react';

export const TwitterThreadFormatter: React.FC = () => {
  const [input, setInput] = useState('');
  const [tweets, setTweets] = useState<string[]>([]);
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);

  useEffect(() => {
    if (!input.trim()) return setTweets([]);
    // Simple logic: split by ~280 chars or specific newline markers
    const parts = input.match(/.{1,260}(\s|$)/g) || [];
    setTweets(parts.map((p, i) => `${i + 1}/ ${p.trim()} 🧵`));
  }, [input]);

  return (
    <div className="bg-[#0a0a0a] border border-blue-500/30 rounded-[3rem] p-8 max-w-4xl mx-auto shadow-2xl relative overflow-hidden">
      <div className="flex items-center gap-4 mb-8">
        <div className="p-3 bg-blue-500/10 rounded-2xl text-blue-500"><Twitter size={28} /></div>
        <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">X Thread Master Scribe</h2>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <textarea value={input} onChange={e => setInput(e.target.value)} placeholder="Paste your long-form manuscript here..." className="w-full h-80 bg-black border border-white/5 rounded-2xl p-6 text-white text-sm outline-none focus:border-blue-500/40 resize-none shadow-inner" />
        <div className="space-y-4 max-h-80 overflow-y-auto custom-scrollbar pr-2">
          {tweets.map((t, i) => (
            <div key={i} className="p-4 bg-white/5 rounded-xl border border-white/5 relative group">
              <p className="text-[11px] text-gray-300 italic leading-relaxed">{t}</p>
              <button onClick={() => { navigator.clipboard.writeText(t); setCopiedIdx(i); setTimeout(()=>setCopiedIdx(null), 2000); }} className="absolute top-2 right-2 text-blue-400 opacity-0 group-hover:opacity-100 transition-opacity">
                {copiedIdx === i ? <Check size={14}/> : <Copy size={14}/>}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
