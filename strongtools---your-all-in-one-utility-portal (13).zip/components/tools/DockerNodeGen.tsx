
import React, { useState } from 'react';
import { Package, Download, Copy, Check, Zap, Container } from 'lucide-react';

export const DockerNodeGen: React.FC = () => {
  const [nodeVersion, setNodeVersion] = useState('20');
  const [isAlpine, setIsAlpine] = useState(true);
  const [port, setPort] = useState('3000');
  const [copied, setCopied] = useState(false);

  const dockerfile = `# Production Node.js Environment
FROM node:${nodeVersion}${isAlpine ? '-alpine' : ''}

# Create app directory
WORKDIR /usr/src/app

# Install app dependencies
COPY package*.json ./
RUN npm ci --only=production

# Bundle app source
COPY . .

EXPOSE ${port}
CMD [ "npm", "start" ]`;

  return (
    <div className="bg-[#0a0a0a] border border-blue-500/30 rounded-[3rem] p-8 max-w-4xl mx-auto shadow-2xl relative overflow-hidden">
      <div className="flex items-center gap-4 mb-8">
        <div className="p-3 bg-blue-500/10 rounded-2xl text-blue-500"><Container size={28} /></div>
        <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">Docker Forge (Node.js)</h2>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase text-gray-500 tracking-widest">Node Version</label>
            <select value={nodeVersion} onChange={e => setNodeVersion(e.target.value)} className="w-full bg-black border border-white/10 rounded-xl p-3 text-white">
              <option value="22">Node 22 (Current)</option>
              <option value="20">Node 20 (LTS)</option>
              <option value="18">Node 18</option>
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase text-gray-500 tracking-widest">Port Exposure</label>
            <input type="text" value={port} onChange={e => setPort(e.target.value)} className="w-full bg-black border border-white/10 rounded-xl p-3 text-white" />
          </div>
          <button onClick={() => setIsAlpine(!isAlpine)} className={`w-full py-3 rounded-xl border text-[10px] font-black uppercase transition-all ${isAlpine ? 'bg-blue-600 text-white' : 'bg-white/5 text-gray-500'}`}>
            Use Alpine Linux (Slim)
          </button>
        </div>
        <div className="p-6 bg-black rounded-2xl border border-blue-500/20 relative group">
          <pre className="text-[10px] font-mono text-emerald-400">{dockerfile}</pre>
          <button onClick={() => { navigator.clipboard.writeText(dockerfile); setCopied(true); setTimeout(()=>setCopied(false), 2000); }} className="absolute top-4 right-4 text-blue-500">
            {copied ? <Check size={18}/> : <Copy size={18}/>}
          </button>
        </div>
      </div>
    </div>
  );
};
