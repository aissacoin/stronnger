import React, { useState } from 'react';
import { FileText, Copy, Trash2, Clock, Hash, AlignLeft, Check, Info, ShieldCheck, Zap } from 'lucide-react';
import { useLanguage } from '../LanguageContext';

export const WordCounter: React.FC = () => {
  const [text, setText] = useState('');
  const [copied, setCopied] = useState(false);
  const { t, language } = useLanguage();
  const langT = t.tools['word-counter'];
  const isAr = language === 'ar';

  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  const chars = text.length;
  const sentences = text.split(/[.!?]+/).filter(Boolean).length;
  const readingTime = Math.ceil(words / 200) || 0;

  const handleCopy = () => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-12" dir={t.dir}>
      <div className="bg-[#141414] border border-[#D4AF37]/30 rounded-[2.5rem] p-8 max-w-4xl mx-auto shadow-2xl transition-all">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-[#D4AF37]/10 rounded-2xl border border-[#D4AF37]/20">
              <FileText className="text-[#D4AF37]" size={28} />
            </div>
            <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">{langT.name}</h2>
          </div>
          <div className="flex gap-3">
            <button 
              onClick={() => setText('')}
              className="p-3 bg-white/5 border border-white/10 rounded-xl text-gray-400 hover:text-rose-400 transition-all"
            >
              <Trash2 size={20} />
            </button>
            <button 
              onClick={handleCopy}
              className={`px-6 py-3 border rounded-xl transition-all flex items-center gap-2 font-black uppercase text-[10px] tracking-widest ${copied ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400' : 'bg-[#D4AF37]/10 border-[#D4AF37]/30 text-[#D4AF37] hover:bg-[#D4AF37] hover:text-black'}`}
            >
              {copied ? <Check size={16} /> : <Copy size={16} />}
              {copied ? t.common.copied : t.common.copy}
            </button>
          </div>
        </div>

        <div className="space-y-8">
          <textarea 
            value={text}
            onChange={(e) => setText(e.target.value)}
            className={`w-full h-72 bg-black border border-[#D4AF37]/20 rounded-[2rem] p-8 text-[#D4AF37] text-lg leading-relaxed focus:outline-none focus:border-[#D4AF37] transition-all placeholder-[#D4AF37]/10 custom-scrollbar resize-none ${isAr ? 'text-right' : 'text-left'}`}
            placeholder={langT.internal.placeholder}
          />

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-black/50 border border-white/5 p-6 rounded-3xl text-center group hover:border-[#D4AF37]/40 transition-all">
               <Hash className="text-[#D4AF37]/30 mx-auto mb-2" size={20} />
               <div className="text-3xl font-black text-white tabular-nums">{words}</div>
               <div className="text-[9px] uppercase font-bold text-gray-500 tracking-[0.3em] mt-2">{langT.internal.words}</div>
            </div>
            <div className="bg-black/50 border border-white/5 p-6 rounded-3xl text-center group hover:border-[#D4AF37]/40 transition-all">
               <AlignLeft className="text-[#D4AF37]/30 mx-auto mb-2" size={20} />
               <div className="text-3xl font-black text-white tabular-nums">{chars}</div>
               <div className="text-[9px] uppercase font-bold text-gray-500 tracking-[0.3em] mt-2">{langT.internal.chars}</div>
            </div>
            <div className="bg-black/50 border border-white/5 p-6 rounded-3xl text-center group hover:border-[#D4AF37]/40 transition-all">
               <FileText className="text-[#D4AF37]/30 mx-auto mb-2" size={20} />
               <div className="text-3xl font-black text-white tabular-nums">{sentences}</div>
               <div className="text-[9px] uppercase font-bold text-gray-500 tracking-[0.3em] mt-2">{langT.internal.sentences}</div>
            </div>
            <div className="bg-black/50 border border-white/5 p-6 rounded-3xl text-center group hover:border-[#D4AF37]/40 transition-all">
               <Clock className="text-[#D4AF37]/30 mx-auto mb-2" size={20} />
               <div className="text-3xl font-black text-white tabular-nums">{readingTime}{isAr ? 'د' : 'm'}</div>
               <div className="text-[9px] uppercase font-bold text-gray-500 tracking-[0.3em] mt-2">{langT.internal.time}</div>
            </div>
          </div>
        </div>
      </div>

      {/* الشرح العربي أسفل الأداة */}
      {isAr && (
        <div className="max-w-4xl mx-auto p-12 bg-white/[0.02] border-2 border-dashed border-white/10 rounded-[4rem] relative overflow-hidden group">
           <Info className="absolute -bottom-10 -right-10 opacity-[0.03] text-white rotate-12" size={300} />
           <div className="relative z-10 space-y-6 text-right">
              <div className="flex items-center justify-end gap-3 text-[#D4AF37]">
                 <h3 className="text-2xl font-black uppercase italic tracking-tighter">ما هو عداد الكلمات وكيف تستفيد منه؟</h3>
                 <ShieldCheck size={24} />
              </div>
              <p className="text-lg text-gray-400 leading-relaxed italic">
                "تعتبر أداة عداد الكلمات ضرورية لكل كاتب، مدون، أو طالب علم. فهي لا تكتفي بحساب عدد الكلمات فحسب، بل تحلل بنية النص لتعطيك إحصائيات دقيقة حول عدد الحروف والفقرات. ميزة 'وقت القراءة' تساعدك على تقدير المدة التي سيستغرقها القارئ في استيعاب مقالك، مما يحسن من تجربة المستخدم (UX) في موقعك أو مدونتك."
              </p>
              <div className="flex items-center justify-end gap-4 opacity-40">
                 <Zap size={14} className="text-[#D4AF37]" />
                 <span className="text-[10px] font-black uppercase tracking-widest">تحديث فوري • معالجة محلية 100%</span>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};