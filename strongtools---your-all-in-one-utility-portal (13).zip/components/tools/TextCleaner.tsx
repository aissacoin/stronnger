
import React, { useState, useCallback } from 'react';
import { Eraser, Copy, Check, Trash2, ShieldCheck, Zap, AlignLeft, Type, ArrowRight, Scissors, Layers, FileCode } from 'lucide-react';
import { useLanguage } from '../LanguageContext';

export const TextCleaner: React.FC = () => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [copied, setCopied] = useState(false);
  const { t } = useLanguage();
  const langT = t.tools['text-cleaner'];

  const [options, setOptions] = useState({
    removeEmptyLines: true,
    trimWhitespace: true,
    removeDuplicates: false,
    stripHtml: false,
    removeSpecialChars: false
  });

  const cleanText = useCallback(() => {
    if (!input) { setOutput(''); return; }
    let result = input;
    if (options.stripHtml) result = result.replace(/<[^>]*>?/gm, '');
    if (options.removeSpecialChars) result = result.replace(/[^\w\s\d]/gi, '');
    let lines = result.split(/\r?\n/);
    if (options.trimWhitespace) lines = lines.map(line => line.trim());
    if (options.removeEmptyLines) lines = lines.filter(line => line.length > 0);
    if (options.removeDuplicates) lines = Array.from(new Set(lines));
    setOutput(lines.join('\n'));
  }, [input, options]);

  React.useEffect(() => { cleanText(); }, [cleanText]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
      <div className="lg:col-span-4 space-y-6">
        <label className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500 italic px-2">{langT.protocols}</label>
        <div className="grid grid-cols-1 gap-2">
          {[
            { id: 'removeEmptyLines', label: langT.emptyLines, icon: <AlignLeft size={14}/> },
            { id: 'trimWhitespace', label: langT.whitespace, icon: <Scissors size={14}/> },
            { id: 'removeDuplicates', label: langT.duplicates, icon: <Layers size={14}/> },
            { id: 'stripHtml', label: langT.html, icon: <FileCode size={14}/> },
            { id: 'removeSpecialChars', label: langT.special, icon: <Type size={14}/> },
          ].map((opt) => (
            <button
              key={opt.id}
              onClick={() => setOptions(prev => ({ ...prev, [opt.id]: !prev[opt.id as keyof typeof prev] }))}
              className={`flex items-center justify-between p-4 rounded-2xl border transition-all ${options[opt.id as keyof typeof options] ? 'bg-[#D4AF37]/10 border-[#D4AF37] text-[#D4AF37]' : 'bg-white/5 border-white/5 text-gray-500'}`}
            >
              <div className="flex items-center gap-3">{opt.icon} <span className="text-[10px] font-black uppercase">{opt.label}</span></div>
            </button>
          ))}
        </div>
      </div>
      <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        <textarea 
          value={input} onChange={(e) => setInput(e.target.value)}
          className="w-full h-80 bg-black border border-white/5 rounded-[2.5rem] p-6 text-white text-sm outline-none focus:border-[#D4AF37]/40 shadow-inner"
          placeholder={langT.label}
        />
        <div className="relative">
          <textarea readOnly value={output} className="w-full h-80 bg-[#D4AF37]/5 border border-[#D4AF37]/20 rounded-[2.5rem] p-6 text-gray-300 text-sm shadow-inner italic" />
          <button onClick={() => { navigator.clipboard.writeText(output); setCopied(true); setTimeout(()=>setCopied(false), 2000); }} className="absolute top-4 right-4 text-[#D4AF37]">
            {copied ? <Check size={18}/> : <Copy size={18}/>}
          </button>
        </div>
      </div>
    </div>
  );
};
