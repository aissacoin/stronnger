import React, { useState } from 'react';
import { UserCheck, Sparkles, Loader2, Copy, Check, Trash2, BrainCircuit, ShieldCheck, Info } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { useLanguage } from '../LanguageContext';

type HumanizeMode = 'Natural' | 'Academic' | 'Creative';

export const AIHumanizer: React.FC = () => {
  const { t, language } = useLanguage();
  const isAr = language === 'ar';
  
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [mode, setMode] = useState<HumanizeMode>('Natural');

  const humanizeText = async () => {
    if (!input.trim() || loading) return;
    setLoading(true);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const instructions = {
      Natural: "Rewrite the following text to sound like a real person wrote it. Use casual yet professional English, vary sentence lengths. Use standard numbers 0123456789.",
      Academic: "Paraphrase the text to maintain a sophisticated scholarly tone. Use standard numbers 0123456789.",
      Creative: "Transform this text into an engaging, story-like prose. Use standard numbers 0123456789."
    };

    try {
      const response = await ai.models.generateContent({
        model: "gemini-1.5-flash",
        contents: `TEXT TO HUMANIZE:\n${input}`,
        config: { systemInstruction: instructions[mode], temperature: 0.7 }
      });
      setOutput(response.text || "");
    } catch (err) { setOutput("Error: Node synchronization failure."); }
    finally { setLoading(false); }
  };

  return (
    <div className="space-y-12" dir={t.dir}>
      <div className="bg-[#0a0a0a] border border-[#D4AF37]/30 rounded-[3rem] p-8 max-w-4xl mx-auto shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-8">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-[#D4AF37]/10 rounded-2xl border border-[#D4AF37]/20 text-[#D4AF37]">
              <BrainCircuit size={28} />
            </div>
            <div className={isAr ? 'text-right' : 'text-left'}>
              <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">{isAr ? 'أنسنة النصوص AI' : 'AI Text Humanizer'}</h2>
              <p className="text-[9px] font-bold text-[#D4AF37]/40 uppercase tracking-[0.4em]">{isAr ? 'تحويل النصوص الآلية إلى بشرية' : 'Neural Rewriting Node'}</p>
            </div>
          </div>
          <div className="flex bg-white/5 p-1 rounded-2xl border border-white/10">
            {(['Natural', 'Academic', 'Creative'] as HumanizeMode[]).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${mode === m ? 'bg-[#D4AF37] text-black shadow-lg' : 'text-gray-500 hover:text-white'}`}
              >
                {m === 'Natural' ? (isAr ? 'طبيعي' : 'Natural') : m === 'Academic' ? (isAr ? 'أكاديمي' : 'Academic') : (isAr ? 'إبداعي' : 'Creative')}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="w-full h-80 bg-black border border-white/5 rounded-[2rem] p-6 text-white text-sm outline-none focus:border-[#D4AF37]/40 resize-none shadow-inner"
            placeholder={isAr ? "الصق نص الذكاء الاصطناعي هنا لإعادة صياغته..." : "Paste AI text here..."}
          />
          <div className="relative w-full h-80 bg-[#D4AF37]/5 border border-[#D4AF37]/20 rounded-[2rem] p-6 text-gray-200 text-sm overflow-y-auto leading-relaxed italic shadow-inner">
            {loading ? <Loader2 className="animate-spin text-[#D4AF37] mx-auto" /> : output || (isAr ? "في انتظار معالجة النصوص..." : "Awaiting transformation...")}
          </div>
        </div>

        <button
          onClick={humanizeText}
          disabled={loading || !input.trim()}
          className="w-full mt-8 bg-[#D4AF37] text-black py-6 rounded-[2.5rem] font-black text-xl uppercase tracking-tighter italic flex items-center justify-center gap-4 hover:scale-[1.02] shadow-xl"
        >
          {loading ? <Loader2 className="animate-spin" /> : <Sparkles />}
          {isAr ? 'إعادة صياغة النص' : 'Transmute Prose'}
        </button>
      </div>

      <div className="max-w-4xl mx-auto p-12 bg-white/[0.01] border-2 border-dashed border-white/10 rounded-[4rem] relative overflow-hidden group">
         <Info className="absolute -bottom-10 -right-10 opacity-[0.03] text-white rotate-12" size={300} />
         <div className="relative z-10 space-y-6 text-right">
            <div className="flex items-center justify-end gap-3 text-[#D4AF37]">
               <h3 className="text-2xl font-black uppercase italic tracking-tighter">{isAr ? 'ما هي أنسنة النصوص؟' : 'What is Humanizer?'}</h3>
               <ShieldCheck size={24} />
            </div>
            <p className="text-lg text-gray-400 leading-relaxed italic">
              {isAr ? 
                "تعتبر النصوص التي ينتجها الذكاء الاصطناعي أحياناً جافة أو متكررة، مما يجعل كشفها سهلاً من قبل محركات البحث. تقوم هذه الأداة بإعادة بناء الجمل، تنويع طول العبارات، وإدخال لمسات بشرية تجعل النص يبدو وكأنه كُتب بيد كاتب محترف. الوضع 'الأكاديمي' مثالي للأبحاث، بينما 'الإبداعي' يضيف لغة وصفية وقصصية للمحتوى." 
                : "AI-generated text can often feel dry or repetitive. This tool rebuilds sentences..."}
            </p>
         </div>
      </div>
    </div>
  );
};