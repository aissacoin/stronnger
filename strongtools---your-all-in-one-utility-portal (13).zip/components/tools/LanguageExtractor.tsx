import React, { useState, useCallback, useEffect } from 'react';
import { Languages, Copy, Check, Trash2, Download, ShieldCheck, Zap, Info, Filter, Globe, MousePointer2 } from 'lucide-react';
import { useLanguage } from '../LanguageContext';

interface LanguageRange {
  name: string;
  native: string;
  regex: RegExp;
}

const LANGUAGES: LanguageRange[] = [
  { name: 'Arabic', native: 'العربية', regex: /[\u0600-\u06FF]/g },
  { name: 'English', native: 'English', regex: /[a-zA-Z]/g },
  { name: 'Numbers', native: '123...', regex: /[0-9\u0660-\u0669]/g }
];

export const LanguageExtractor: React.FC = () => {
  const { t, language } = useLanguage();
  const isAr = language === 'ar';
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [keepLangs, setKeepLangs] = useState<string[]>(['Arabic', 'English']);
  const [copied, setCopied] = useState(false);

  const processExtraction = useCallback(() => {
    if (!input) { setOutput(''); return; }
    const selectedLangs = LANGUAGES.filter(l => keepLangs.includes(l.name));
    let result = '';
    for (const char of input) {
      let isAllowed = false;
      for (const lang of selectedLangs) {
        lang.regex.lastIndex = 0;
        if (lang.regex.test(char)) { isAllowed = true; break; }
      }
      if (/\s/.test(char)) isAllowed = true;
      if (isAllowed) result += char;
    }
    setOutput(result.replace(/ +/g, ' ').trim());
  }, [input, keepLangs]);

  useEffect(() => { processExtraction(); }, [processExtraction]);

  const toggleLang = (name: string) => {
    setKeepLangs(prev => prev.includes(name) ? prev.filter(l => l !== name) : [...prev, name]);
  };

  return (
    <div className="space-y-12" dir={t.dir}>
      <div className="bg-[#0a0a0a] border border-[#D4AF37]/30 rounded-[3rem] p-8 max-w-7xl mx-auto shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-10">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-[#D4AF37]/10 rounded-2xl text-[#D4AF37]"><Languages size={28} /></div>
            <div className={isAr ? 'text-right' : 'text-left'}>
              <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">{isAr ? 'فلتر اللغات' : 'Linguistic Extractor'}</h2>
              <p className="text-[9px] font-bold text-[#D4AF37]/40 uppercase tracking-[0.4em]">{isAr ? 'عزل النصوص حسب اللغة' : 'Script Isolation Node'}</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
           <textarea 
            value={input} onChange={(e) => setInput(e.target.value)}
            className={`w-full h-64 bg-black border border-white/5 rounded-[2.5rem] p-8 text-white text-sm outline-none focus:border-[#D4AF37]/40 ${isAr ? 'text-right' : 'text-left'}`}
            placeholder={isAr ? "الصق النص المختلط هنا..." : "Paste mixed text here..."}
           />
           <textarea 
            readOnly value={output}
            className={`w-full h-64 bg-[#D4AF37]/5 border border-[#D4AF37]/20 rounded-[2.5rem] p-8 text-gray-300 text-sm outline-none ${isAr ? 'text-right' : 'text-left'}`}
            placeholder={isAr ? "النتيجة المفلترة ستظهر هنا..." : "Filtered text will appear here..."}
           />
        </div>

        <div className="bg-white/5 p-6 rounded-3xl flex flex-wrap gap-4 justify-center">
           {LANGUAGES.map(lang => (
             <button key={lang.name} onClick={() => toggleLang(lang.name)} className={`px-6 py-3 rounded-xl border transition-all ${keepLangs.includes(lang.name) ? 'bg-[#D4AF37] text-black' : 'bg-black text-gray-500'}`}>
                {isAr ? lang.native : lang.name}
             </button>
           ))}
        </div>
      </div>
    </div>
  );
};