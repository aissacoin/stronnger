import React, { useState, useEffect } from 'react';
import { FileText, Copy, Trash2, Download, Save, Check, History, ShieldCheck, Zap, Info, AlignLeft, Hash, Clock } from 'lucide-react';
import { useLanguage } from '../LanguageContext';

export const OnlineNotepad: React.FC = () => {
  const { t, language } = useLanguage();
  const isAr = language === 'ar';
  
  const [content, setContent] = useState<string>(() => {
    return localStorage.getItem('st_notepad_registry') || '';
  });
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  const words = content.trim() ? content.trim().split(/\s+/).length : 0;
  const chars = content.length;
  const lines = content.split('\n').filter(l => l.length > 0).length;
  const readTime = Math.ceil(words / 200);

  useEffect(() => {
    const timeout = setTimeout(() => {
      localStorage.setItem('st_notepad_registry', content);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    }, 1000);
    return () => clearTimeout(timeout);
  }, [content]);

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = isAr ? `مخطوطة_سيادية_${new Date().getTime()}.txt` : `Sovereign_Manuscript_${new Date().getTime()}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleClear = () => {
    if (window.confirm(isAr ? "تحذير: سيتم مسح كافة البيانات المسجلة، هل أنت متأكد؟" : "Archival Warning: This will wipe the current registry. Proceed?")) {
      setContent('');
      localStorage.removeItem('st_notepad_registry');
    }
  };

  return (
    <div className="space-y-12" dir={t.dir}>
      <div className="bg-[#0a0a0a] border border-[#D4AF37]/30 rounded-[3rem] p-8 max-w-6xl mx-auto shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#D4AF37]/50 to-transparent"></div>
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-10">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-[#D4AF37]/10 rounded-2xl border border-[#D4AF37]/20 text-[#D4AF37]">
              <FileText size={28} />
            </div>
            <div className={isAr ? 'text-right' : 'text-left'}>
              <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">{isAr ? 'المفكرة السيادية' : 'Sovereign Notepad'}</h2>
              <p className="text-[9px] font-bold text-[#D4AF37]/40 uppercase tracking-[0.4em]">{isAr ? 'وحدة تدوين المخطوطات الآمنة' : 'Secure Manuscript Drafting Unit'}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
             <div className={`flex items-center gap-2 px-4 py-2 rounded-xl border transition-all duration-500 ${saved ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-white/5 border-white/10 text-gray-500'}`}>
                {saved ? <Check size={12} /> : <Save size={12} />}
                <span className="text-[9px] font-black uppercase tracking-widest">{saved ? (isAr ? 'تم تحديث السجل' : 'Registry Updated') : (isAr ? 'جاري المزامنة' : 'Auto-Sync Active')}</span>
             </div>
             <button onClick={handleClear} className="p-3 bg-white/5 border border-white/10 rounded-xl text-gray-600 hover:text-rose-500 transition-all"><Trash2 size={18}/></button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-8">
          <div className="lg:col-span-9 space-y-6">
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="relative w-full h-[500px] bg-black border border-white/10 rounded-[2.5rem] p-10 text-gray-200 text-lg leading-relaxed outline-none focus:border-[#D4AF37]/40 transition-all placeholder-white/5 resize-none shadow-inner custom-scrollbar italic"
              placeholder={isAr ? "ابدأ بكتابة مخطوطتك هنا... يتم حفظ المحتوى تلقائياً في ذاكرة المتصفح المحلية." : "Begin penning your sovereign manuscript here..."}
            />
          </div>

          <div className="lg:col-span-3 flex flex-col gap-4">
             <div className="bg-white/[0.02] border border-white/5 rounded-[2rem] p-6 space-y-6">
                <div className="space-y-4">
                   <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest text-gray-500 border-b border-white/5 pb-2">
                      <div className="flex items-center gap-2"><AlignLeft size={12}/> {isAr ? 'الكلمات' : 'Words'}</div>
                      <span className="text-white tabular-nums">{words}</span>
                   </div>
                   <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest text-gray-500 border-b border-white/5 pb-2">
                      <div className="flex items-center gap-2"><Hash size={12}/> {isAr ? 'الحروف' : 'Chars'}</div>
                      <span className="text-white tabular-nums">{chars}</span>
                   </div>
                   <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest text-gray-500 border-b border-white/5 pb-2">
                      <div className="flex items-center gap-2"><History size={12}/> {isAr ? 'الأسطر' : 'Lines'}</div>
                      <span className="text-white tabular-nums">{lines}</span>
                   </div>
                   <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest text-gray-500">
                      <div className="flex items-center gap-2"><Clock size={12}/> {isAr ? 'وقت القراءة' : 'Read Time'}</div>
                      <span className="text-white tabular-nums">{readTime}{isAr ? ' د' : 'm'}</span>
                   </div>
                </div>

                <div className="flex flex-col gap-3 pt-4">
                   <button 
                    onClick={handleCopy}
                    className={`w-full py-4 rounded-2xl flex items-center justify-center gap-3 font-black uppercase text-[10px] tracking-[0.2em] transition-all ${copied ? 'bg-emerald-500 text-black' : 'bg-white/5 border border-white/10 text-white hover:bg-white/10'}`}
                   >
                     {copied ? <Check size={16}/> : <Copy size={16}/>}
                     {copied ? (isAr ? 'تم النسخ' : 'Captured') : (isAr ? 'نسخ الكل' : 'Copy All')}
                   </button>
                   <button 
                    onClick={handleDownload}
                    className="w-full bg-[#D4AF37] text-black py-4 rounded-2xl flex items-center justify-center gap-3 font-black uppercase text-[10px] tracking-[0.2em] hover:scale-[1.02] transition-all"
                   >
                     <Download size={16}/> {isAr ? 'تصدير .txt' : 'Export .txt'}
                   </button>
                </div>
             </div>
          </div>
        </div>
      </div>

      {/* الشرح التقني أسفل الأداة */}
      <div className="max-w-4xl mx-auto p-12 bg-[#D4AF37]/5 border-2 border-dashed border-[#D4AF37]/20 rounded-[4rem] relative overflow-hidden group">
         <Info className="absolute -bottom-10 -right-10 opacity-[0.03] text-[#D4AF37] rotate-12" size={300} />
         <div className="relative z-10 space-y-6 text-right">
            <div className="flex items-center justify-end gap-3 text-[#D4AF37]">
               <h3 className="text-2xl font-black uppercase italic tracking-tighter">{isAr ? 'بروتوكول الخصوصية: المفكرة المحلية' : 'Protocol: Local Notepad'}</h3>
               <ShieldCheck size={24} />
            </div>
            <p className="text-lg text-gray-400 leading-relaxed italic">
              {isAr ? 
                "تعتمد المفكرة السيادية على مبدأ 'البيانات أولاً للمستخدم'. لا يتم إرسال أي نص تكتبه إلى خوادمنا؛ بدلاً من ذلك، يتم تخزين بياناتك في ذاكرة التخزين المحلية (LocalStorage) الخاصة بمتصفحك. هذا يعني أن مخطوطاتك تظل خاصة بك بالكامل، ومحمية من أي تتبع خارجي، مع ميزة الحفظ التلقائي التي تضمن عدم فقدان عملك حتى لو أغلقت الصفحة." 
                : "The Sovereign Notepad operates on the 'User-First Data' principle. None of your text is transmitted to our servers..."}
            </p>
         </div>
      </div>
    </div>
  );
};