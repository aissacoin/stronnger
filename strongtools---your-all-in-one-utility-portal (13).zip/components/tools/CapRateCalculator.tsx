
import React, { useState, useEffect } from 'react';
import { Building, TrendingUp, Wallet, ShieldCheck, Zap, Info } from 'lucide-react';

export const CapRateCalculator: React.FC = () => {
  const [purchasePrice, setPurchasePrice] = useState(500000);
  const [monthlyRent, setMonthlyRent] = useState(3500);
  const [annualExpenses, setAnnualExpenses] = useState(8000);

  const [results, setResults] = useState({ annualIncome: 0, capRate: 0, netOperating: 0 });

  useEffect(() => {
    const annualGross = monthlyRent * 12;
    const netOperating = annualGross - annualExpenses;
    const capRate = (netOperating / purchasePrice) * 100;
    setResults({ annualIncome: annualGross, capRate, netOperating });
  }, [purchasePrice, monthlyRent, annualExpenses]);

  return (
    <div className="bg-[#0a0a0a] border border-blue-500/30 rounded-[3rem] p-8 max-w-4xl mx-auto shadow-2xl relative overflow-hidden">
      <div className="flex items-center gap-4 mb-10">
        <div className="p-3 bg-blue-500/10 rounded-2xl text-blue-500"><Building size={28} /></div>
        <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">Real Estate Cap Rate Oracle</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        <div className="space-y-6">
           <div className="space-y-1">
             <label className="text-[9px] font-black uppercase text-gray-500 ml-2 italic">Purchase Price ($)</label>
             <input type="number" value={purchasePrice} onChange={e => setPurchasePrice(Number(e.target.value))} className="w-full bg-black border border-white/5 rounded-2xl p-4 text-white font-black tabular-nums outline-none" />
           </div>
           <div className="space-y-1">
             <label className="text-[9px] font-black uppercase text-gray-500 ml-2 italic">Monthly Rental Income ($)</label>
             <input type="number" value={monthlyRent} onChange={e => setMonthlyRent(Number(e.target.value))} className="w-full bg-black border border-white/5 rounded-2xl p-4 text-emerald-400 font-black tabular-nums outline-none" />
           </div>
           <div className="space-y-1">
             <label className="text-[9px] font-black uppercase text-gray-500 ml-2 italic">Annual Expenses (Taxes, Maint) ($)</label>
             <input type="number" value={annualExpenses} onChange={e => setAnnualExpenses(Number(e.target.value))} className="w-full bg-black border border-white/5 rounded-2xl p-4 text-rose-400 font-black tabular-nums outline-none" />
           </div>
        </div>

        <div className="bg-blue-700 rounded-[3rem] p-10 flex flex-col justify-center items-center text-center space-y-6 shadow-2xl">
            <span className="text-[10px] font-black uppercase tracking-[0.5em] text-white/50">Capitalization Rate</span>
            <div className="text-8xl font-black text-white italic tracking-tighter tabular-nums">{results.capRate.toFixed(2)}%</div>
            <div className="w-full pt-6 border-t border-white/10 grid grid-cols-2 gap-4">
               <div>
                  <div className="text-[8px] font-black uppercase text-white/40">Net Operating Income</div>
                  <div className="text-lg font-black text-white italic tabular-nums">${results.netOperating.toLocaleString()}</div>
               </div>
               <div>
                  <div className="text-[8px] font-black uppercase text-white/40">Gross Annual</div>
                  <div className="text-lg font-black text-white italic tabular-nums">${results.annualIncome.toLocaleString()}</div>
               </div>
            </div>
        </div>
      </div>
    </div>
  );
};
