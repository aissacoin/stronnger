
import React, { useState } from 'react';
import { UserCircle, Briefcase, Sparkles, Loader2, Copy, Check, ShieldCheck } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

export const AILinkedInBioArchitect: React.FC = () => {
  const [skills, setSkills] = useState('');
  const [experience, setExperience] = useState('');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const generateBio = async () => {
    if (!skills.trim() || loading) return;
    setLoading(true);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: `Write a compelling, professional LinkedIn "About" section. 
        Skills: ${skills}
        Experience: ${experience}
        Style: Authoritative yet personable, first-person narrative, include a call to action at the end.`,
      });
      setOutput(response.text || '');
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  return (
    <div className="bg-[#0a0a0a] border border-[#D4AF37]/30 rounded-[3rem] p-8 max-w-4xl mx-auto shadow-2xl relative overflow-hidden">
      <div className="flex items-center gap-4 mb-8">
        <div className="p-3 bg-[#D4AF37]/10 rounded-2xl text-[#D4AF37]"><UserCircle size={28} /></div>
        <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">LinkedIn Bio Architect</h2>
      </div>
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <input value={skills} onChange={e => setSkills(e.target.value)} placeholder="Key Skills (e.g. React, UX Design)" className="bg-black border border-white/5 rounded-xl p-4 text-white text-sm outline-none focus:border-[#D4AF37]/40" />
          <input value={experience} onChange={e => setExperience(e.target.value)} placeholder="Experience (e.g. 5 years in FinTech)" className="bg-black border border-white/5 rounded-xl p-4 text-white text-sm outline-none focus:border-[#D4AF37]/40" />
        </div>
        <button onClick={generateBio} disabled={loading || !skills} className="w-full bg-[#D4AF37] text-black py-5 rounded-2xl font-black uppercase flex items-center justify-center gap-2">
          {loading ? <Loader2 className="animate-spin" /> : <Briefcase size={20} />} Construct Authority
        </button>
        {output && (
          <div className="p-6 bg-white/[0.02] rounded-2xl border border-white/10 relative whitespace-pre-wrap text-sm text-gray-300 leading-relaxed italic">
            {output}
            <button onClick={() => { navigator.clipboard.writeText(output); setCopied(true); setTimeout(()=>setCopied(false), 2000); }} className="absolute top-4 right-4 text-[#D4AF37]">
              {copied ? <Check size={18}/> : <Copy size={18}/>}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
