
import React, { useState } from 'react';
import { 
  BookOpen, Sparkles, Loader2, Copy, Check, Trash2, 
  Clock, GraduationCap, Microscope, ListChecks, 
  ShieldCheck, Zap, Info, FileText, Send
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

type Level = 'Primary' | 'Secondary' | 'University' | 'Professional';
type Tone = 'Interactive' | 'Lecturing' | 'Practical' | 'Inquiry-Based';

export const LessonPlanGen: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [level, setLevel] = useState<Level>('Secondary');
  const [duration, setDuration] = useState('45');
  const [tone, setTone] = useState<Tone>('Interactive');
  const [language, setLanguage] = useState<'English' | 'Arabic'>('English');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generatePlan = async () => {
    if (!topic.trim() || loading) return;

    setLoading(true);
    setError(null);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    try {
      const prompt = `Act as a senior pedagogical expert. Create a comprehensive lesson plan for the topic: "${topic}".
      Target Level: ${level}
      Class Duration: ${duration} minutes
      Teaching Style: ${tone}
      Language: ${language}
      
      The plan must include:
      1. Learning Objectives (Bloom's Taxonomy).
      2. Required Materials.
      3. Introduction & Hook (Timed).
      4. Main Activity/Direct Instruction (Timed).
      5. Independent Practice/Group Work.
      6. Assessment & Closure.
      
      Use a professional, clear format with bold headers.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          temperature: 0.7,
          topP: 0.9
        }
      });

      setOutput(response.text || "");
    } catch (err: any) {
      console.error(err);
      setError("Pedagogical Node Failure: The archival engine is currently updating its curriculum.");
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-12">
      <div className="bg-[#0a0a0a] border border-[#D4AF37]/30 rounded-[3rem] p-8 max-w-6xl mx-auto shadow-2xl relative overflow-hidden selection:bg-[#D4AF37] selection:text-black">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#D4AF37]/50 to-transparent"></div>
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-10">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-[#D4AF37]/10 rounded-2xl border border-[#D4AF37]/20 text-[#D4AF37]">
              <BookOpen size={28} />
            </div>
            <div>
              <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">AI Lesson Plan Architect</h2>
              <p className="text-[9px] font-bold text-[#D4AF37]/40 uppercase tracking-[0.4em]">Pedagogical Framework Forge</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
             <div className="flex bg-white/5 p-1 rounded-xl border border-white/10">
                {(['English', 'Arabic'] as const).map((lang) => (
                  <button
                    key={lang}
                    onClick={() => setLanguage(lang)}
                    className={`px-4 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${language === lang ? 'bg-[#D4AF37] text-black shadow-lg' : 'text-gray-500 hover:text-white'}`}
                  >
                    {lang}
                  </button>
                ))}
             </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Input Side */}
          <div className="lg:col-span-5 space-y-8">
            <div className="space-y-4">
              <label className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500 italic px-2">Topic or Subject Name</label>
              <textarea
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                className="w-full h-24 bg-black border border-white/5 rounded-2xl p-4 text-white text-sm outline-none focus:border-[#D4AF37]/40 transition-all placeholder-white/5 resize-none shadow-inner"
                placeholder="e.g., Photosynthesis and Ecosystems..."
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <label className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500 italic px-2">Academic Level</label>
                <select 
                  value={level}
                  onChange={(e) => setLevel(e.target.value as Level)}
                  className="w-full bg-black border border-white/5 rounded-xl p-3 text-white text-xs font-bold outline-none focus:border-[#D4AF37]/40"
                >
                  <option value="Primary">Primary</option>
                  <option value="Secondary">Secondary</option>
                  <option value="University">University</option>
                  <option value="Professional">Professional</option>
                </select>
              </div>
              <div className="space-y-4">
                <label className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500 italic px-2">Duration (Mins)</label>
                <input 
                  type="number"
                  value={duration}
                  onChange={(e) => setDuration(e.target.value)}
                  className="w-full bg-black border border-white/5 rounded-xl p-3 text-white text-xs font-bold outline-none focus:border-[#D4AF37]/40 tabular-nums"
                />
              </div>
            </div>

            <div className="space-y-4">
              <label className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500 italic px-2">Instructional Aura</label>
              <div className="grid grid-cols-2 gap-2">
                {(['Interactive', 'Lecturing', 'Practical', 'Inquiry-Based'] as Tone[]).map((t) => (
                  <button
                    key={t}
                    onClick={() => setTone(t)}
                    className={`py-3 rounded-xl border text-[9px] font-black uppercase tracking-widest transition-all ${tone === t ? 'bg-[#D4AF37] text-black border-[#D4AF37]' : 'bg-white/5 border-white/5 text-gray-500 hover:text-white'}`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={generatePlan}
              disabled={loading || !topic.trim()}
              className="w-full bg-[#D4AF37] text-black py-6 rounded-[2.5rem] font-black text-xl uppercase tracking-tighter italic flex items-center justify-center gap-4 hover:scale-[1.02] active:scale-95 transition-all shadow-[0_20px_50px_rgba(212,175,55,0.3)] disabled:opacity-20"
            >
              {loading ? <Loader2 className="animate-spin" size={24} /> : <Zap size={24} />}
              Architect Lesson Plan
            </button>
          </div>

          {/* Result Side */}
          <div className="lg:col-span-7 flex flex-col h-full space-y-6">
            <div className="flex justify-between items-center px-2">
              <label className="text-[10px] font-black uppercase tracking-[0.4em] text-[#D4AF37] italic">Manuscript Output Registry</label>
              <div className="flex gap-4">
                <button onClick={() => setOutput('')} className="text-gray-600 hover:text-rose-500 transition-colors"><Trash2 size={16}/></button>
                <button 
                  onClick={handleCopy}
                  disabled={!output}
                  className={`flex items-center gap-2 px-3 py-1 rounded-lg transition-all ${copied ? 'text-emerald-400' : 'text-gray-600 hover:text-[#D4AF37]'}`}
                >
                  {copied ? <Check size={14}/> : <Copy size={14}/>}
                  <span className="text-[9px] font-black uppercase tracking-widest">{copied ? 'Sealed' : 'Copy'}</span>
                </button>
              </div>
            </div>
            
            <div className="relative flex-grow bg-black border border-white/5 rounded-[3.5rem] p-10 overflow-hidden group shadow-inner min-h-[500px]">
               <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'repeating-conic-gradient(#fff 0% 25%, #000 0% 50%)', backgroundSize: '40px 40px' }}></div>
               
               {loading ? (
                 <div className="h-full flex flex-col items-center justify-center space-y-6 animate-pulse">
                    <BookOpen size={64} className="text-[#D4AF37] opacity-20" />
                    <p className="text-[10px] font-black uppercase tracking-[0.5em] text-center italic text-[#D4AF37]">Synthesizing Pedagogical Framework...</p>
                 </div>
               ) : output ? (
                 <div className={`relative z-10 w-full h-full overflow-y-auto custom-scrollbar whitespace-pre-wrap text-gray-300 text-sm leading-relaxed italic ${language === 'Arabic' ? 'text-right font-serif' : 'text-left font-sans'}`} dir={language === 'Arabic' ? 'rtl' : 'ltr'}>
                    {output}
                 </div>
               ) : (
                 <div className="h-full flex flex-col items-center justify-center opacity-10 space-y-6">
                   <FileText size={100} className="mx-auto" />
                   <p className="text-[10px] font-black uppercase tracking-[0.5em]">Awaiting Subject Ingestion</p>
                 </div>
               )}
            </div>
          </div>
        </div>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6 opacity-40">
           <div className="flex items-center gap-4 p-4 bg-white/5 rounded-2xl border border-white/5">
             <GraduationCap size={20} className="text-[#D4AF37]" />
             <p className="text-[9px] font-black uppercase tracking-widest leading-loose italic">Bloom's Taxonomy Logic Integrated</p>
           </div>
           <div className="flex items-center gap-4 p-4 bg-white/5 rounded-2xl border border-white/5">
             <Clock size={20} className="text-[#D4AF37]" />
             <p className="text-[9px] font-black uppercase tracking-widest leading-loose italic">Temporal Resource Allocation Verified</p>
           </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-12 bg-[#D4AF37]/5 border-2 border-dashed border-[#D4AF37]/20 rounded-[4rem] relative overflow-hidden group">
         <Info className="absolute -bottom-10 -right-10 opacity-[0.03] text-[#D4AF37] rotate-12" size={300} />
         <div className="relative z-10 space-y-6">
            <div className="flex items-center gap-3 text-[#D4AF37]">
               <ListChecks size={24} />
               <h3 className="text-2xl font-black uppercase italic tracking-tighter font-serif-scholarly">Technical Protocol: Educational Synthesis</h3>
            </div>
            <p className="text-lg text-gray-400 leading-relaxed italic">
              "The Lesson Plan Architect utilizes a **Pedagogical Logic Handshake**. By processing topic ingestion against structured educational benchmarks, the engine creates a multi-phased learning manuscript. It automatically allocates time slots for direct instruction and independent practice based on the defined class duration, ensuring that curricular milestones are achieved with absolute mathematical rigor."
            </p>
         </div>
      </div>
    </div>
  );
};
