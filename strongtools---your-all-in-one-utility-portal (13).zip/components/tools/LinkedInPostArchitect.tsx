
import React, { useState } from 'react';
import { Linkedin, Sparkles, Loader2, Copy, Check, Zap, ShieldCheck } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

export const LinkedInPostArchitect: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const generatePost = async () => {
    if (!topic.trim() || loading) return;
    setLoading(true);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const response = await ai.models.generateContent({
        model: "gemini-1.5-flash",
        contents: `Write a professional LinkedIn thought leadership post about: "${topic}". Use bullet points and a call to action. Use numbers 0123456789.`,
      });
      setOutput(response.text || "");
    } catch (err) {
      setOutput("Error: 1.5-Flash node failure.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#0a0a0a] border border-blue-600/30 rounded-[3rem] p-8 max-w-4xl mx-auto shadow-2xl relative overflow-hidden">
      <div className="flex items-center gap-4 mb-8">
        <div className="p-3 bg-blue-600/10 rounded-2xl text-blue-500"><Linkedin size={28} /></div>
        <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">LinkedIn Post Architect</h2>
      </div>
      <div className="space-y-6">
        <textarea value={topic} onChange={e => setTopic(e.target.value)} className="w-full h-32 bg-black border border-white/5 rounded-2xl p-6 text-white outline-none focus:border-blue-500/40" placeholder="Post topic..." />
        <button onClick={generatePost} disabled={loading} className="w-full bg-blue-600 text-white py-5 rounded-2xl font-black uppercase flex items-center justify-center gap-2">
          {loading ? <Loader2 className="animate-spin" /> : <Zap />} Synthesize Thought Leadership
        </button>
        {output && (
          <div className="p-6 bg-white/5 rounded-2xl border border-white/10 relative">
            <p className="text-gray-300 text-sm whitespace-pre-wrap italic leading-relaxed">{output}</p>
            <button onClick={() => { navigator.clipboard.writeText(output); setCopied(true); setTimeout(()=>setCopied(false), 2000); }} className="absolute top-4 right-4 text-blue-400">
              {copied ? <Check /> : <Copy />}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
