
import React, { useState } from 'react';
import { LayoutGrid, Upload, Trash2, Instagram, Info, ShieldCheck } from 'lucide-react';

export const InstaGridPlanner: React.FC = () => {
  const [images, setImages] = useState<string[]>([]);

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Cast items to File explicitly to fix type error on line 11
    const files = Array.from(e.target.files || []) as File[];
    files.forEach(file => {
      const url = URL.createObjectURL(file);
      setImages(prev => [url, ...prev].slice(0, 12));
    });
  };

  return (
    <div className="bg-[#0a0a0a] border border-pink-500/30 rounded-[3rem] p-8 max-w-5xl mx-auto shadow-2xl relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-pink-500 to-purple-500"></div>
      <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-10">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-pink-500/10 rounded-2xl text-pink-500"><Instagram size={28} /></div>
          <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">Insta Grid Architect</h2>
        </div>
        <div className="relative cursor-pointer bg-white/5 border border-white/10 p-4 rounded-2xl hover:bg-white/10 transition-all flex items-center gap-3">
          <Upload size={20} className="text-pink-500" />
          <span className="text-[10px] font-black uppercase text-white">Inject Visual Registry</span>
          {/* Fixed reference to handleFileUpload to use handleUpload as defined above */}
          <input type="file" multiple onChange={handleUpload} className="absolute inset-0 opacity-0 cursor-pointer" accept="image/*" />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-1 bg-[#111] p-1 rounded-2xl max-w-sm mx-auto shadow-inner border border-white/5">
        {Array.from({ length: 9 }).map((_, i) => (
          <div key={i} className="aspect-square bg-zinc-900 overflow-hidden relative group">
            {images[i] ? (
              <>
                <img src={images[i]} className="w-full h-full object-cover" />
                <button onClick={() => setImages(images.filter((_, idx) => idx !== i))} className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center text-rose-500 transition-opacity">
                  <Trash2 size={24}/>
                </button>
              </>
            ) : (
              <div className="w-full h-full flex items-center justify-center opacity-10">
                <LayoutGrid size={32} />
              </div>
            )}
          </div>
        ))}
      </div>
      <p className="text-center text-[8px] font-black text-gray-500 uppercase tracking-widest mt-8 italic">Simulated Archival Grid • Order as displayed in Live Registry</p>
    </div>
  );
};
