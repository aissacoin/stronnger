
import React, { useState, useRef } from 'react';
import { Palette, Upload, Loader2, Zap, Download, ShieldCheck, Info, Camera, Trash2, Check } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

const COLOR_PRESETS = [
  { name: 'Platinum Blonde', hex: '#E5E4E2' },
  { name: 'Rose Gold', hex: '#B76E79' },
  { name: 'Midnight Blue', hex: '#191970' },
  { name: 'Crimson Red', hex: '#DC143C' },
  { name: 'Aureate Gold', hex: '#D4AF37' }
];

export const HairColorArchitect: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [targetColor, setTargetColor] = useState(COLOR_PRESETS[0]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve((reader.result as string).split(',')[1]);
      reader.onerror = (error) => reject(error);
    });
  };

  const transmuteHair = async () => {
    if (!file || loading) return;
    setLoading(true);
    setResult(null);

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const base64 = await fileToBase64(file);
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [
            { inlineData: { data: base64, mimeType: file.type } },
            { text: `Identify the person's hair in this image. Change the hair color to exactly ${targetColor.name} (Hex: ${targetColor.hex}). Maintain natural textures, lighting, and reflections. Return the modified image only.` }
          ]
        }
      });

      let base64Data = '';
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          base64Data = part.inlineData.data;
          break;
        }
      }
      if (base64Data) setResult(`data:image/png;base64,${base64Data}`);
    } catch (err) {
      console.error(err);
      alert("Neural desync: Failed to map hair follicles.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#0a0a0a] border border-pink-500/30 rounded-[3rem] p-8 max-w-5xl mx-auto shadow-2xl relative overflow-hidden selection:bg-pink-500 selection:text-white">
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-pink-500/50 to-transparent"></div>
      
      <div className="flex items-center gap-4 mb-10">
        <div className="p-3 bg-pink-500/10 rounded-2xl text-pink-400"><Palette size={28} /></div>
        <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">AI Hair Color Architect</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        <div className="lg:col-span-5 space-y-8">
          <div 
            onClick={() => fileInputRef.current?.click()}
            className={`h-64 bg-black border-2 border-dashed rounded-[2.5rem] flex flex-col items-center justify-center cursor-pointer transition-all ${preview ? 'border-pink-500/40' : 'border-white/5 hover:border-pink-500/40'}`}
          >
            {preview ? <img src={preview} className="h-full w-full object-contain p-4" /> : (
              <>
                <Upload size={32} className="text-gray-700 mb-2" />
                <span className="text-[10px] font-black uppercase text-gray-500 tracking-widest">Inject Portrait Source</span>
              </>
            )}
            <input type="file" ref={fileInputRef} onChange={e => { const f = e.target.files?.[0]; if(f){ setFile(f); setPreview(URL.createObjectURL(f)); } }} className="hidden" accept="image/*" />
          </div>

          <div className="space-y-4">
             <label className="text-[10px] font-black uppercase text-gray-500 italic px-2">Select Target Pigment</label>
             <div className="grid grid-cols-2 gap-2">
                {COLOR_PRESETS.map(c => (
                  <button key={c.hex} onClick={() => setTargetColor(c)} className={`p-3 rounded-xl border text-[9px] font-black uppercase transition-all flex items-center gap-3 ${targetColor.hex === c.hex ? 'bg-pink-600 text-white border-pink-600 shadow-lg' : 'bg-white/5 text-gray-500 border-white/5'}`}>
                    <div className="w-3 h-3 rounded-full border border-white/10" style={{ backgroundColor: c.hex }}></div>
                    {c.name}
                  </button>
                ))}
             </div>
          </div>

          <button onClick={transmuteHair} disabled={loading || !file} className="w-full bg-pink-600 text-white py-6 rounded-[2.5rem] font-black text-xl uppercase tracking-tighter italic flex items-center justify-center gap-4 hover:scale-[1.02] active:scale-95 transition-all shadow-[0_20px_50px_rgba(219,39,119,0.3)]">
            {loading ? <Loader2 className="animate-spin" /> : <Zap />} Execute Transmutation
          </button>
        </div>

        <div className="lg:col-span-7 flex flex-col h-full space-y-6">
          <div className="flex justify-between items-center px-2">
            <label className="text-[10px] font-black uppercase tracking-[0.4em] text-pink-500 italic">Neural Result Registry</label>
            <button onClick={() => { setPreview(null); setFile(null); setResult(null); }} className="text-gray-600 hover:text-rose-500 transition-colors"><Trash2 size={16}/></button>
          </div>
          
          <div className="relative flex-grow bg-black border border-white/5 rounded-[3.5rem] p-6 flex items-center justify-center min-h-[450px] overflow-hidden group shadow-inner">
             {loading ? (
               <div className="text-center space-y-4 animate-pulse">
                  <div className="w-20 h-20 bg-pink-500/20 rounded-full flex items-center justify-center text-pink-500 mx-auto border border-pink-500/30">
                    <Loader2 className="animate-spin" size={32} />
                  </div>
                  <p className="text-[10px] font-black uppercase tracking-[0.5em] text-pink-500">Mapping Follicles...</p>
               </div>
             ) : result ? (
               <div className="relative z-10 w-full h-full flex flex-col items-center justify-center animate-in zoom-in duration-700">
                  <img src={result} className="max-w-full max-h-full rounded-2xl shadow-2xl" alt="Result" />
                  <button onClick={() => { const a = document.createElement('a'); a.href = result; a.download = 'Aureate_Hair_Archive.png'; a.click(); }} className="mt-6 flex items-center gap-3 px-8 py-3 bg-pink-600 text-white rounded-xl font-black text-xs uppercase tracking-widest hover:scale-105 transition-all">
                    <Download size={16}/> Export Archive
                  </button>
               </div>
             ) : (
               <div className="text-center opacity-10 space-y-6">
                 <Camera size={100} className="mx-auto" />
                 <p className="text-[10px] font-black uppercase tracking-[0.5em]">Awaiting Visual Input</p>
               </div>
             )}
          </div>
        </div>
      </div>
    </div>
  );
};
