import React, { useState } from 'react';
import { Type, Copy, Trash2, Check, ArrowRightLeft, ShieldCheck, Zap, Info } from 'lucide-react';
import { useLanguage } from '../LanguageContext';

type CaseType = 'UPPER' | 'LOWER' | 'TITLE' | 'SENTENCE' | 'CAMEL' | 'PASCAL';

export const CaseConverter: React.FC = () => {
  const { t, language } = useLanguage();
  const isAr = language === 'ar';
  
  const [text, setText] = useState('');
  const [copied, setCopied] = useState(false);

  const convert = (type: CaseType) => {
    if (!text.trim()) return;
    let result = text;
    const words = text.toLowerCase().split(/\s+/).filter(w => w.length > 0);
    switch (type) {
      case 'UPPER': result = text.toUpperCase(); break;
      case 'LOWER': result = text.toLowerCase(); break;
      case 'TITLE': result = text.toLowerCase().replace(/\b\w/g, s => s.toUpperCase()); break;
      case 'SENTENCE': result = text.toLowerCase().replace(/(^\s*\w|[.!?]\s*\w)/g, s => s.toUpperCase()); break;
      case 'CAMEL': result = words.map((word, i) => i === 0 ? word : word.charAt(0).toUpperCase() + word.slice(1)).join(''); break;
      case 'PASCAL': result = words.map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(''); break;
    }
    setText(result);
  };

  const handleCopy = () => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-12" dir={t.dir}>
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        <div className="lg:col-span-8 space-y-6">
          <div className="relative group">
            <div className="flex justify-between items-center px-4 mb-3">
               <label className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500 italic">{isAr ? 'النص المدخل' : 'Input Text'}</label>
               <div className="flex gap-4">
                  <button onClick={() => setText('')} className="text-gray-600 hover:text-rose-500 transition-colors"><Trash2 size={16}/></button>
                  <button onClick={handleCopy} className={`flex items-center gap-2 text-[10px] font-black uppercase tracking-widest transition-all ${copied ? 'text-emerald-400' : 'text-gray-600 hover:text-[#D4AF37]'}`}>
                    {copied ? <Check size={14}/> : <Copy size={14}/>} {copied ? (isAr ? 'تم النسخ' : 'Copied') : (isAr ? 'نسخ' : 'Copy')}
                  </button>
               </div>
            </div>
            <textarea 
              value={text}
              onChange={(e) => setText(e.target.value)}
              className="w-full h-80 bg-black border border-white/5 rounded-[2.5rem] p-8 text-white text-lg font-medium outline-none focus:border-[#D4AF37]/40 transition-all shadow-inner placeholder-white/5 resize-none italic custom-scrollbar"
              placeholder={isAr ? "الصق النص الإنجليزي هنا لتغيير حالة الأحرف..." : "Paste English text here..."}
            />
          </div>
        </div>

        <div className="lg:col-span-4 flex flex-col gap-3">
          {[
            { id: 'UPPER', label: isAr ? 'أحرف كبيرة (UPPER)' : 'UPPER CASE' },
            { id: 'LOWER', label: isAr ? 'أحرف صغيرة (lower)' : 'lower case' },
            { id: 'TITLE', label: isAr ? 'حالة العنوان (Title)' : 'Title Case' },
            { id: 'SENTENCE', label: isAr ? 'حالة الجملة (Sentence)' : 'Sentence case' },
            { id: 'CAMEL', label: 'camelCase' },
            { id: 'PASCAL', label: 'PascalCase' }
          ].map((p) => (
            <button
              key={p.id}
              onClick={() => convert(p.id as CaseType)}
              className="group relative flex flex-col items-start p-5 bg-white/5 border border-white/5 rounded-2xl hover:border-[#D4AF37]/40 transition-all hover:bg-[#D4AF37]/5 text-left"
            >
              <div className="flex items-center justify-between w-full">
                <span className="text-[11px] font-black uppercase tracking-widest text-white group-hover:text-[#D4AF37] transition-colors">{p.label}</span>
                <ArrowRightLeft size={12} className="opacity-20 group-hover:opacity-100" />
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-12 bg-white/[0.01] border-2 border-dashed border-white/10 rounded-[4rem] relative overflow-hidden group">
         <Info className="absolute -bottom-10 -right-10 opacity-[0.03] text-white rotate-12" size={300} />
         <div className="relative z-10 space-y-6 text-right">
            <div className="flex items-center justify-end gap-3 text-[#D4AF37]">
               <h3 className="text-2xl font-black uppercase italic tracking-tighter">{isAr ? 'كيف يعمل محول الحالة؟' : 'How it works?'}</h3>
               <Zap size={24} />
            </div>
            <p className="text-lg text-gray-400 leading-relaxed italic">
              {isAr ? 
                "تم تصميم هذه الأداة للتعامل مع النصوص اللاتينية (الإنجليزية بشكل أساسي) لتغيير شكل الحروف فورياً. يقوم 'حالة العنوان' بجعل الحرف الأول من كل كلمة كبيراً، بينما 'حالة الجملة' يكتشف بدايات الجمل بعد النقاط ويقوم بتكبيرها. كما تدعم الأداة تنسيقات المبرمجين مثل camelCase و PascalCase لتسهيل كتابة الأكواد." 
                : "This tool is designed to handle Latin scripts to instantly change character casing..."}
            </p>
         </div>
      </div>
    </div>
  );
};