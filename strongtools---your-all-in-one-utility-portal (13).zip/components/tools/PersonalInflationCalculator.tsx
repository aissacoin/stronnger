
import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, Wallet, Globe, ShieldCheck, Zap, 
  Info, AlertCircle, PieChart, ArrowRight, 
  Landmark, Coins, Calendar, History, Loader2, Sparkles
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

interface RegionalPreset {
  name: string;
  rate: number;
  currency: string;
}

const REGIONS: RegionalPreset[] = [
  { name: 'United States', rate: 3.1, currency: '$' },
  { name: 'United Kingdom', rate: 4.0, currency: '£' },
  { name: 'European Union', rate: 2.8, currency: '€' },
  { name: 'Saudi Arabia', rate: 1.6, currency: 'SAR' },
  { name: 'Egypt', rate: 29.8, currency: 'EGP' },
  { name: 'Turkey', rate: 64.7, currency: 'TRY' },
  { name: 'India', rate: 5.1, currency: '₹' },
];

export const PersonalInflationCalculator: React.FC = () => {
  const [monthlyExpenses, setMonthlyExpenses] = useState(3000);
  const [years, setYears] = useState(5);
  const [selectedRegion, setSelectedRegion] = useState(REGIONS[0]);
  const [customRate, setCustomRate] = useState<number | null>(null);
  
  const [results, setResults] = useState({
    futureCost: 0,
    purchasingPowerLost: 0,
    multiplier: 0
  });

  const [advice, setAdvice] = useState('');
  const [loadingAdvice, setLoadingAdvice] = useState(false);

  // Sovereignty Protocol: Strict adherence to 0123456789 numerals
  const toStd = (n: number | string) => {
    return String(n).replace(/[٠-٩]/g, d => "0123456789"["٠١٢٣٤٥٦٧٨٩".indexOf(d)]);
  };

  const sanitizeInput = (val: string) => {
    return val.replace(/[^0-9.]/g, '');
  };

  const currentRate = customRate !== null ? customRate : selectedRegion.rate;

  useEffect(() => {
    // Scientific Compound Inflation Formula: FV = PV * (1 + r)^n
    const rateDecimal = currentRate / 100;
    const multiplier = Math.pow(1 + rateDecimal, years);
    const futureCost = monthlyExpenses * multiplier;
    const purchasingPowerLost = futureCost - monthlyExpenses;

    setResults({
      futureCost,
      purchasingPowerLost,
      multiplier
    });
  }, [monthlyExpenses, years, selectedRegion, customRate]);

  const getAIAdvice = async () => {
    setLoadingAdvice(true);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const prompt = `Act as a Senior Macroeconomist. Analyze this personal inflation data:
    Current Monthly Expenses: ${selectedRegion.currency}${monthlyExpenses}
    Projected Inflation Rate: ${currentRate}% in ${selectedRegion.name}
    Temporal Horizon: ${years} years.
    
    Provide a professional analysis of purchasing power erosion and strategic mitigation in 150 words. Use standard 0123456789 numerals.`;

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt
      });
      setAdvice(response.text || "");
    } catch (err) {
      setAdvice("Archive node desynchronized. Analysis unavailable.");
    } finally {
      setLoadingAdvice(false);
    }
  };

  return (
    <div className="space-y-12">
      <div className="bg-[#0a0a0a] border border-[#D4AF37]/30 rounded-[3rem] p-8 max-w-6xl mx-auto shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#D4AF37]/50 to-transparent"></div>
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-12">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-[#D4AF37]/10 rounded-2xl border border-[#D4AF37]/20 text-[#D4AF37]">
              <TrendingUp size={28} />
            </div>
            <div>
              <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">Inflation Impact Oracle</h2>
              <p className="text-[9px] font-bold text-[#D4AF37]/40 uppercase tracking-[0.4em]">Purchasing Power Erosion Matrix</p>
            </div>
          </div>
          <div className="flex items-center gap-2 px-5 py-2 bg-emerald-500/5 border border-emerald-500/20 rounded-xl">
             <ShieldCheck size={14} className="text-emerald-400" />
             <span className="text-[9px] font-black uppercase tracking-widest text-emerald-400/60 tabular-nums">0123456789 Standard Enforced</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          <div className="lg:col-span-5 space-y-10 border-r border-white/5 pr-10">
            <div className="space-y-6">
              <div className="flex items-center gap-2 text-[#D4AF37]/60 italic mb-2">
                <Globe size={14}/>
                <span className="text-[10px] font-black uppercase tracking-widest">Regional Baseline</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {REGIONS.map((r) => (
                  <button
                    key={r.name}
                    onClick={() => {setSelectedRegion(r); setCustomRate(null);}}
                    className={`p-3 rounded-xl border text-[10px] font-black uppercase tracking-widest transition-all ${selectedRegion.name === r.name && customRate === null ? 'bg-[#D4AF37] text-black border-[#D4AF37]' : 'bg-white/5 border-white/5 text-gray-500 hover:border-white/20'}`}
                  >
                    {r.name}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-6">
              <div className="flex items-center gap-2 text-[#D4AF37]/60 italic mb-2">
                <Landmark size={14}/>
                <span className="text-[10px] font-black uppercase tracking-widest">Fiscal Parameters</span>
              </div>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[9px] font-black uppercase text-gray-500 ml-2 italic">Monthly Living Cost</label>
                  <div className="relative">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-600 font-bold">{selectedRegion.currency}</div>
                    <input 
                      type="text" 
                      value={monthlyExpenses} 
                      onChange={(e) => setMonthlyExpenses(Number(sanitizeInput(toStd(e.target.value))))}
                      className="w-full bg-black border border-white/5 rounded-xl p-4 pl-12 text-white font-black text-lg outline-none focus:border-[#D4AF37]/40 tabular-nums"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[9px] font-black uppercase text-gray-500 ml-2 italic">Horizon (Years)</label>
                    <input 
                      type="text" 
                      value={years} 
                      onChange={(e) => setYears(Number(sanitizeInput(toStd(e.target.value))))}
                      className="w-full bg-black border border-white/5 rounded-xl p-3 text-white font-bold text-sm outline-none focus:border-[#D4AF37]/40 tabular-nums"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black uppercase text-gray-500 ml-2 italic">Inflation %</label>
                    <input 
                      type="text" 
                      value={currentRate} 
                      onChange={(e) => setCustomRate(Number(sanitizeInput(toStd(e.target.value))))}
                      className="w-full bg-black border border-white/5 rounded-xl p-3 text-[#D4AF37] font-bold text-sm outline-none focus:border-[#D4AF37]/40 tabular-nums"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 flex flex-col h-full space-y-6">
            <div className="relative flex-grow bg-black border border-white/5 rounded-[3.5rem] p-10 overflow-hidden flex flex-col justify-center items-center text-center shadow-inner">
               <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'repeating-conic-gradient(#fff 0% 25%, #000 0% 50%)', backgroundSize: '40px 40px' }}></div>
               
               <div className="relative z-10 space-y-2">
                  <p className="text-[10px] font-black uppercase tracking-[0.6em] text-[#D4AF37]/60 mb-4">Future Cost of Survival</p>
                  <div className="text-7xl md:text-8xl font-black text-white italic tracking-tighter tabular-nums drop-shadow-2xl">
                    {selectedRegion.currency}{toStd(results.futureCost.toLocaleString('en-US', {maximumFractionDigits: 0}))}
                  </div>
                  <p className="text-lg font-bold text-rose-500/60 uppercase tracking-[0.2em] italic">
                    +{toStd(((results.multiplier - 1) * 100).toFixed(1))}% Nominal Increase
                  </p>
               </div>

               <div className="relative z-10 grid grid-cols-2 gap-4 w-full mt-12">
                  <div className="p-6 bg-white/[0.02] border border-white/5 rounded-[2.5rem] group hover:border-[#D4AF37]/30 transition-all">
                     <div className="text-xl font-black text-rose-500 tabular-nums italic">-{selectedRegion.currency}{toStd(results.purchasingPowerLost.toLocaleString('en-US', {maximumFractionDigits: 0}))}</div>
                     <div className="text-[8px] font-bold text-gray-500 uppercase tracking-widest mt-1">Value Erosion (Loss)</div>
                  </div>
                  <div className="p-6 bg-white/[0.02] border border-white/5 rounded-[2.5rem] group hover:border-[#D4AF37]/30 transition-all">
                     <div className="text-xl font-black text-white tabular-nums italic">{toStd(results.multiplier.toFixed(2))}x</div>
                     <div className="text-[8px] font-bold text-gray-500 uppercase tracking-widest mt-1">Decay Multiplier</div>
                  </div>
               </div>
            </div>
            
            {/* AD SLOT IN TOOL */}
            <div className="w-full h-24 bg-white/[0.02] border border-white/5 rounded-2xl flex items-center justify-center italic text-[8px] text-zinc-800 uppercase tracking-[0.5em]">
              Responsive Financial Ad Node (728x90)
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
