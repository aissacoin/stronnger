import React, { useState, useEffect } from 'react';
import { Plus, Minus, Activity, Info, ShieldCheck, Zap } from 'lucide-react';
import { useLanguage } from '../LanguageContext';

export const BMICalculator: React.FC = () => {
  const [weight, setWeight] = useState<number>(70);
  const [height, setHeight] = useState<number>(170);
  const [result, setResult] = useState<{ bmi: string; status: string } | null>(null);
  const { t, language } = useLanguage();
  const isAr = language === 'ar';
  const langT = t.tools['bmi-calc'];

  const calculateBMI = () => {
    if (weight > 0 && height > 0) {
      const hMeter = height / 100;
      const bmiValue = (weight / (hMeter * hMeter)).toFixed(1);
      let status = '';
      const bmiFloat = parseFloat(bmiValue);
      
      if (bmiFloat < 18.5) status = langT.status.u;
      else if (bmiFloat < 25) status = langT.status.n;
      else if (bmiFloat < 30) status = langT.status.o;
      else status = langT.status.ob;
      
      setResult({ bmi: bmiValue, status });
    }
  };

  const adjust = (type: 'w' | 'h', amount: number) => {
    if (type === 'w') setWeight(prev => Math.max(10, prev + amount));
    else setHeight(prev => Math.max(50, prev + amount));
  };

  useEffect(() => {
    calculateBMI();
  }, [weight, height, t]);

  return (
    <div className="space-y-12" dir={t.dir}>
      <div className="bg-[#0a0a0a] border border-[#D4AF37]/30 rounded-[3rem] p-8 max-w-xl mx-auto shadow-[0_0_80px_rgba(212,175,55,0.1)] relative overflow-hidden">
        <div className="flex items-center gap-4 mb-10">
          <div className="p-3 bg-[#D4AF37]/10 rounded-2xl text-[#D4AF37]"><Activity size={24} /></div>
          <div className={isAr ? 'text-right' : 'text-left'}>
            <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">{langT.name}</h2>
            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">{langT.internal.status}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <label className="block text-[10px] uppercase tracking-[0.4em] text-gray-500 font-black text-center">{langT.weight}</label>
            <div className="flex items-center justify-between bg-white/5 border border-white/10 rounded-2xl p-2">
              <button onClick={() => adjust('w', -1)} className="w-10 h-10 rounded-xl bg-white/5 text-[#D4AF37] hover:bg-[#D4AF37] hover:text-black transition-all"><Minus size={16} /></button>
              <span className="text-3xl font-black text-white tabular-nums">{weight}</span>
              <button onClick={() => adjust('w', 1)} className="w-10 h-10 rounded-xl bg-white/5 text-[#D4AF37] hover:bg-[#D4AF37] hover:text-black transition-all"><Plus size={16} /></button>
            </div>
          </div>

          <div className="space-y-4">
            <label className="block text-[10px] uppercase tracking-[0.4em] text-gray-500 font-black text-center">{langT.height}</label>
            <div className="flex items-center justify-between bg-white/5 border border-white/10 rounded-2xl p-2">
              <button onClick={() => adjust('h', -1)} className="w-10 h-10 rounded-xl bg-white/5 text-[#D4AF37] hover:bg-[#D4AF37] hover:text-black transition-all"><Minus size={16} /></button>
              <span className="text-3xl font-black text-white tabular-nums">{height}</span>
              <button onClick={() => adjust('h', 1)} className="w-10 h-10 rounded-xl bg-white/5 text-[#D4AF37] hover:bg-[#D4AF37] hover:text-black transition-all"><Plus size={16} /></button>
            </div>
          </div>
        </div>

        {result && (
          <div className="mt-12 p-8 bg-[#D4AF37]/5 border border-[#D4AF37]/20 rounded-[2.5rem] text-center animate-in zoom-in">
            <div className="text-5xl font-black text-[#D4AF37] mb-2 tabular-nums italic">{result.bmi}</div>
            <div className="text-[10px] uppercase tracking-[0.5em] text-white font-black opacity-60">{result.status}</div>
          </div>
        )}
      </div>

      {isAr && (
        <div className="max-w-xl mx-auto p-12 bg-white/[0.01] border-2 border-dashed border-white/10 rounded-[4rem] relative overflow-hidden group">
           <Info className="absolute -bottom-10 -right-10 opacity-[0.03] text-white rotate-12" size={300} />
           <div className="relative z-10 space-y-6 text-right">
              <div className="flex items-center justify-end gap-3 text-[#D4AF37]">
                 <h3 className="text-2xl font-black uppercase italic tracking-tighter">{langT.name} • كيف تعمل؟</h3>
                 <Zap size={24} />
              </div>
              <p className="text-lg text-gray-400 leading-relaxed italic">
                {langT.explanation}
              </p>
           </div>
        </div>
      )}
    </div>
  );
};