
import React, { useState } from 'react';
import { Sparkles, Loader2, Copy, Check, Trash2, Zap, MessageSquare, Target, ShieldCheck, Flame, Eye, Brain, Info, MousePointer2 } from 'lucide-react';
import { GoogleGenAI, Type } from "@google/genai";

type TriggerType = 'Curiosity' | 'Controversial' | 'Authority' | 'Fear' | 'Relatability';

interface HookResult {
  hook: string;
  trigger: string;
  logic: string;
}

export const AIHookGenerator: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [trigger, setTrigger] = useState<TriggerType>('Curiosity');
  const [language, setLanguage] = useState<'English' | 'Arabic'>('English');
  const [results, setResults] = useState<HookResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  const generateHooks = async () => {
    if (!topic.trim() || loading) return;

    setLoading(true);
    setError(null);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    try {
      const prompt = `Act as a Viral Content Strategist for TikTok and Instagram Reels. 
      Topic: "${topic}"
      Psychological Trigger: ${trigger}
      Language: ${language}
      
      Generate 3 highly engaging "Hooks" (the first 3 seconds of a video).
      Requirements:
      1. Use "Pattern Interrupt" techniques.
      2. Keep them under 10 words.
      3. Provide a brief "Why it works" logic for each.
      4. Return ONLY a JSON array of objects with keys "hook", "trigger", and "logic".`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                hook: { type: Type.STRING },
                trigger: { type: Type.STRING },
                logic: { type: Type.STRING }
              },
              required: ["hook", "trigger", "logic"]
            }
          }
        }
      });

      const data = JSON.parse(response.text || "[]");
      setResults(data);
    } catch (err: any) {
      console.error(err);
      setError("Logical Synthesis Error: The engagement node is temporarily desynchronized.");
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const handleClear = () => {
    setTopic('');
    setResults([]);
    setError(null);
  };

  return (
    <div className="space-y-12">
      <div className="bg-[#0a0a0a] border border-[#D4AF37]/30 rounded-[3rem] p-8 max-w-6xl mx-auto shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#D4AF37]/50 to-transparent"></div>
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-10">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-[#D4AF37]/10 rounded-2xl border border-[#D4AF37]/20 text-[#D4AF37]">
              <Flame size={28} className={loading ? 'animate-pulse' : ''} />
            </div>
            <div>
              <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">Viral Hook Architect</h2>
              <p className="text-[9px] font-bold text-[#D4AF37]/40 uppercase tracking-[0.4em]">Attention Economy Core v2.0</p>
            </div>
          </div>
          <div className="flex bg-white/5 p-1 rounded-xl border border-white/10">
            {(['English', 'Arabic'] as const).map((lang) => (
              <button
                key={lang}
                onClick={() => setLanguage(lang)}
                className={`px-6 py-2 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${language === lang ? 'bg-[#D4AF37] text-black shadow-lg' : 'text-zinc-500 hover:text-white'}`}
              >
                {lang}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Config Side */}
          <div className="lg:col-span-5 space-y-8">
            <div className="space-y-4">
              <label className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500 italic px-2">Video Concept</label>
              <textarea
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                className="w-full h-32 bg-black border border-white/5 rounded-2xl p-5 text-white text-sm outline-none focus:border-[#D4AF37]/40 transition-all placeholder-white/5 resize-none shadow-inner"
                placeholder="What is your video about? (e.g., How to save money, coding tips)..."
              />
            </div>

            <div className="space-y-4">
              <label className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500 italic px-2">Psychological Engine</label>
              <div className="grid grid-cols-2 gap-2">
                {(['Curiosity', 'Controversial', 'Authority', 'Fear', 'Relatability'] as TriggerType[]).map((t) => (
                  <button
                    key={t}
                    onClick={() => setTrigger(t)}
                    className={`py-3 rounded-xl border text-[9px] font-black uppercase tracking-widest transition-all ${trigger === t ? 'bg-[#D4AF37] text-black border-[#D4AF37]' : 'bg-white/5 border-white/5 text-gray-500 hover:text-white'}`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={generateHooks}
              disabled={loading || !topic.trim()}
              className="w-full bg-[#D4AF37] text-black py-6 rounded-[2.5rem] font-black text-xl uppercase tracking-tighter italic flex items-center justify-center gap-4 hover:scale-[1.02] active:scale-95 transition-all shadow-[0_20px_50px_rgba(212,175,55,0.3)] disabled:opacity-20"
            >
              {loading ? <Loader2 className="animate-spin" size={24} /> : <Zap size={24} />}
              Synthesize Viral Openers
            </button>
          </div>

          {/* Results Side */}
          <div className="lg:col-span-7 flex flex-col h-full space-y-6">
            <div className="flex justify-between items-center px-2">
              <label className="text-[10px] font-black uppercase tracking-[0.4em] text-[#D4AF37] italic">Engagement Registry</label>
              <button onClick={handleClear} className="text-gray-600 hover:text-rose-500 transition-colors"><Trash2 size={16}/></button>
            </div>
            
            <div className="relative flex-grow bg-black/60 border border-white/5 rounded-[3.5rem] p-8 space-y-6 overflow-y-auto custom-scrollbar min-h-[450px] shadow-inner">
               {loading ? (
                 <div className="h-full flex flex-col items-center justify-center space-y-6 animate-pulse">
                    <Brain size={64} className="text-[#D4AF37] opacity-20" />
                    <p className="text-[10px] font-black uppercase tracking-[0.5em] text-center italic text-[#D4AF37]">Analyzing Retention Curves...</p>
                 </div>
               ) : results.length > 0 ? (
                 <div className="space-y-4 animate-in fade-in zoom-in duration-500">
                    {results.map((item, i) => (
                      <div key={i} className={`relative group bg-white/[0.03] border border-white/5 rounded-3xl p-6 hover:border-[#D4AF37]/30 transition-all ${language === 'Arabic' ? 'text-right' : 'text-left'}`} dir={language === 'Arabic' ? 'rtl' : 'ltr'}>
                        <div className={`flex justify-between items-start gap-4 mb-4 ${language === 'Arabic' ? 'flex-row-reverse' : ''}`}>
                           <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-xl bg-[#D4AF37]/10 flex items-center justify-center text-[#D4AF37] font-black text-xs">{i+1}</div>
                              <span className="text-[8px] font-black uppercase tracking-widest text-[#D4AF37]/60 border border-[#D4AF37]/20 px-2 py-1 rounded-lg">{item.trigger} Node</span>
                           </div>
                           <button 
                            onClick={() => handleCopy(item.hook, i)}
                            className="p-2 bg-white/5 rounded-lg hover:bg-[#D4AF37] hover:text-black transition-all"
                           >
                             {copiedIndex === i ? <Check size={14}/> : <Copy size={14}/>}
                           </button>
                        </div>
                        <h4 className="text-2xl font-black text-white italic tracking-tighter mb-3 leading-tight">"{item.hook}"</h4>
                        <div className="flex items-start gap-3 p-4 bg-black/40 rounded-2xl border border-white/5">
                           <Info size={14} className="text-[#D4AF37] shrink-0 mt-0.5" />
                           <p className="text-[10px] text-gray-500 leading-relaxed italic">{item.logic}</p>
                        </div>
                      </div>
                    ))}
                 </div>
               ) : (
                 <div className="h-full flex flex-col items-center justify-center opacity-10 space-y-6">
                   <Eye size={100} className="mx-auto" />
                   <p className="text-[10px] font-black uppercase tracking-[0.5em]">Awaiting Media Concept</p>
                 </div>
               )}
            </div>

            {error && (
              <div className="flex items-start gap-4 p-6 bg-rose-500/5 border border-rose-500/20 rounded-2xl">
                <Info className="text-rose-500 shrink-0 mt-0.5" size={20} />
                <p className="text-xs text-rose-400 font-bold uppercase tracking-widest italic">{error}</p>
              </div>
            )}
          </div>
        </div>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6 opacity-40">
           <div className="flex items-center gap-4 p-4 bg-white/5 rounded-2xl border border-white/5">
             <Zap size={20} className="text-[#D4AF37]" />
             <p className="text-[9px] font-black uppercase tracking-widest leading-loose italic">Neural Retention Optimization Active</p>
           </div>
           <div className="flex items-center gap-4 p-4 bg-white/5 rounded-2xl border border-white/5">
             <Brain size={20} className="text-[#D4AF37]" />
             <p className="text-[9px] font-black uppercase tracking-widest leading-loose italic">Psychological Pattern Interrupt Applied</p>
           </div>
        </div>
      </div>

      {/* EDUCATIONAL SECTION */}
      <div className="max-w-4xl mx-auto space-y-24 py-16 px-8 bg-white/[0.01] rounded-[4rem] border border-white/5">
        <section className="space-y-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-[var(--accent)]/10 flex items-center justify-center text-[var(--accent)]">
              <Info size={24} />
            </div>
            <h3 className="text-3xl font-black text-white font-serif-scholarly italic">The Science of the First 3 Seconds</h3>
          </div>
          <p className="text-xl text-gray-400 leading-relaxed italic">
            In the attention economy, the "Hook" is the binary filter between a viewer scrolling past or engaging with your content. Our AI architect utilizes **Pattern Interrupt** logic—statements or questions that disrupt the brain's autopilot. By aligning your concept with specific psychological triggers like the "Curiosity Gap" or "Negative Probability," we maximize the probability of your manuscript reaching a viral meridian.
          </p>
        </section>
      </div>
    </div>
  );
};
