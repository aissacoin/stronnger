
import React, { useState } from 'react';
import { Hash, Sparkles, Loader2, Copy, Check, Zap, ShieldCheck } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

export const HashtagGenerator: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const generateTags = async () => {
    if (!topic.trim() || loading) return;
    setLoading(true);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Generate 30 high-engagement hashtags for: "${topic}". Group them by reach (High, Medium, Low). Return as space separated list.`,
      });
      const result = response.text?.match(/#[a-zA-Z0-9_]+/g) || [];
      setTags(result);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  return (
    <div className="bg-[#0a0a0a] border border-[#D4AF37]/30 rounded-[3rem] p-8 max-w-4xl mx-auto shadow-2xl relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#D4AF37]/50 to-transparent"></div>
      <div className="flex items-center gap-4 mb-8">
        <div className="p-3 bg-[#D4AF37]/10 rounded-2xl text-[#D4AF37]"><Hash size={28} /></div>
        <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">Hashtag Narrative Forge</h2>
      </div>

      <div className="space-y-6">
        <input 
          value={topic} 
          onChange={e => setTopic(e.target.value)} 
          className="w-full bg-black border border-white/5 rounded-2xl p-5 text-white outline-none focus:border-[#D4AF37]/40" 
          placeholder="What is your content about? (e.g. Luxury travel in Dubai)..."
        />

        <button onClick={generateTags} disabled={loading} className="w-full bg-[#D4AF37] text-black py-5 rounded-2xl font-black uppercase flex items-center justify-center gap-2">
          {loading ? <Loader2 className="animate-spin" /> : <Zap />} Extract Viral Anchors
        </button>

        {tags.length > 0 && (
          <div className="p-6 bg-black rounded-2xl border border-white/5 space-y-4">
            <div className="flex flex-wrap gap-2">
              {tags.map((tag, i) => (
                <span key={i} className="text-[10px] font-black text-[#D4AF37] bg-[#D4AF37]/5 px-3 py-1.5 rounded-full border border-[#D4AF37]/20">{tag}</span>
              ))}
            </div>
            <button onClick={() => { navigator.clipboard.writeText(tags.join(' ')); setCopied(true); setTimeout(()=>setCopied(false), 2000); }} className="w-full py-3 bg-white/5 text-white rounded-xl text-[10px] font-black uppercase flex items-center justify-center gap-2">
              {copied ? <Check size={14}/> : <Copy size={14}/>} {copied ? 'Anchors Vaulted' : 'Copy All Anchors'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
