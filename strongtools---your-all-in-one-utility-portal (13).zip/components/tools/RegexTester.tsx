
import React, { useState, useMemo } from 'react';
import { SearchCode, Sparkles, Loader2, Info, Check, AlertTriangle, Code, Play, Wand2, Lightbulb, ShieldCheck } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

export const RegexTester: React.FC = () => {
  const [pattern, setPattern] = useState('[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,}');
  const [testString, setTestString] = useState('Contact us at support@strongtools.site or admin@example.com');
  const [flags, setFlags] = useState('g');
  const [explanation, setExplanation] = useState('');
  const [loadingExplainer, setLoadingExplainer] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const matches = useMemo(() => {
    if (!pattern) return [];
    try {
      setError(null);
      const regex = new RegExp(pattern, flags);
      const found = [];
      let match;
      if (!flags.includes('g')) {
        match = regex.exec(testString);
        if (match) found.push(match);
      } else {
        while ((match = regex.exec(testString)) !== null) {
          found.push(match);
          if (match.index === regex.lastIndex) regex.lastIndex++;
        }
      }
      return found;
    } catch (e: any) {
      setError(e.message);
      return [];
    }
  }, [pattern, testString, flags]);

  const getAIExplanation = async () => {
    if (!pattern || loadingExplainer) return;
    setLoadingExplainer(true);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Explain this Regular Expression logic in detail but concisely: /${pattern}/${flags}. Break down the tokens.`,
      });
      setExplanation(response.text || "Failed to generate explanation.");
    } catch (err) {
      setExplanation("Archival Error: Neural node desync.");
    } finally {
      setLoadingExplainer(false);
    }
  };

  return (
    <div className="bg-[#0a0a0a] border border-orange-500/30 rounded-[3rem] p-8 max-w-5xl mx-auto shadow-2xl relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-orange-500/50 to-transparent"></div>
      <div className="flex items-center gap-4 mb-8">
        <div className="p-3 bg-orange-500/10 rounded-2xl border border-orange-500/20 text-orange-400"><SearchCode size={28} /></div>
        <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">RegEx Logic Architect</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-7 space-y-6">
          <div className="space-y-3">
            <label className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500 px-2 italic">Expression Protocol</label>
            <div className="relative group">
              <span className="absolute left-6 top-1/2 -translate-y-1/2 text-orange-500/40 font-mono text-xl">/</span>
              <input type="text" value={pattern} onChange={(e) => setPattern(e.target.value)} className="w-full bg-black border border-white/5 rounded-2xl py-6 pl-10 pr-16 text-orange-400 font-mono text-sm outline-none focus:border-orange-500/40 transition-all shadow-inner" placeholder="[a-z]+" />
              <span className="absolute right-6 top-1/2 -translate-y-1/2 text-orange-500/40 font-mono text-xl">/{flags}</span>
            </div>
            {error && <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-400 text-[10px] font-bold italic">{error}</div>}
          </div>

          <div className="space-y-3">
            <label className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500 px-2 italic">Subject Manuscript</label>
            <textarea value={testString} onChange={(e) => setTestString(e.target.value)} className="w-full h-40 bg-black border border-white/5 rounded-[2rem] p-6 text-white text-sm outline-none focus:border-orange-500/40 transition-all resize-none shadow-inner" placeholder="Insert text to test..." />
          </div>

          <button onClick={getAIExplanation} disabled={loadingExplainer || !pattern} className="w-full bg-orange-600 text-white py-5 rounded-2xl font-black text-xs uppercase tracking-[0.3em] flex items-center justify-center gap-3 hover:scale-[1.01] transition-all">
            {loadingExplainer ? <Loader2 className="animate-spin" size={18}/> : <Wand2 size={18}/>} Neural Logic Explainer
          </button>
        </div>

        <div className="lg:col-span-5 space-y-6">
          <div className="p-6 bg-white/[0.02] border border-white/5 rounded-[2.5rem] relative overflow-hidden h-[250px] flex flex-col">
            <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-orange-500 mb-6 italic">Detection Registry</h3>
            <div className="flex-grow overflow-auto custom-scrollbar bg-black/40 rounded-2xl border border-white/5 p-6 text-sm leading-relaxed text-gray-300 font-mono">
              {matches.length > 0 ? `Detected ${matches.length} logical node(s).` : 'No matches found.'}
              <div className="mt-4 space-y-2">
                {matches.slice(0, 5).map((m, i) => (
                  <div key={i} className="text-emerald-400 text-xs truncate">[{i}] {m[0]}</div>
                ))}
              </div>
            </div>
          </div>
          <div className="p-6 bg-orange-500/5 border border-orange-500/20 rounded-[2.5rem] min-h-[160px] flex flex-col">
            <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-orange-400 mb-4 italic flex items-center gap-2"><Lightbulb size={12}/> Analysis Insight</h3>
            <div className="text-[11px] text-orange-200/70 italic leading-loose overflow-y-auto max-h-48 custom-scrollbar">
              {explanation || "Awaiting neural handshake to decode expression architecture."}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
