
import React, { useState } from 'react';
import { TrendingUp, Rocket, Sparkles, Loader2, Copy, Check, ShieldCheck } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

export const AITikTokTrendOracle: React.FC = () => {
  const [niche, setNiche] = useState('');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const predictTrends = async () => {
    if (!niche.trim() || loading) return;
    setLoading(true);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Act as a TikTok algorithm expert. Based on the current viral landscape for the niche: "${niche}", predict 3 upcoming trend concepts.
        Provide: Concept Title, Description, and the specific "Viral Hook" to use.`,
      });
      setOutput(response.text || '');
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  return (
    <div className="bg-[#0a0a0a] border border-[#ff0050]/30 rounded-[3rem] p-8 max-w-4xl mx-auto shadow-2xl relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-[#ff0050] to-[#00f2ea]"></div>
      <div className="flex items-center gap-4 mb-8">
        <div className="p-3 bg-[#ff0050]/10 rounded-2xl text-[#ff0050]"><TrendingUp size={28} /></div>
        <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">TikTok Trend Oracle</h2>
      </div>
      <div className="space-y-6">
        <input value={niche} onChange={e => setNiche(e.target.value)} placeholder="Enter your niche (e.g. Cooking, Tech, Fitness)..." className="w-full bg-black border border-white/5 rounded-2xl p-5 text-white outline-none focus:border-[#ff0050]/40" />
        <button onClick={predictTrends} disabled={loading || !niche} className="w-full bg-[#ff0050] text-white py-5 rounded-2xl font-black uppercase flex items-center justify-center gap-2 hover:scale-[1.01] transition-all">
          {loading ? <Loader2 className="animate-spin" /> : <Rocket size={20} />} Analyze Viral Signals
        </button>
        {output && (
          <div className="p-6 bg-white/[0.02] rounded-2xl border border-white/10 relative whitespace-pre-wrap text-sm text-gray-300 leading-relaxed italic">
            {output}
            <button onClick={() => { navigator.clipboard.writeText(output); setCopied(true); setTimeout(()=>setCopied(false), 2000); }} className="absolute top-4 right-4 text-[#00f2ea]">
              {copied ? <Check size={18}/> : <Copy size={18}/>}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
